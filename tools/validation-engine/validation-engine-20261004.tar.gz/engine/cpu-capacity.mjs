import { availableParallelism, cpus } from 'node:os';
import { readFileSync } from 'node:fs';

// OS logical capacity, not physical cores, observed workers, or performance.
export function selectWorkerCapacity({ availableLogicalCpus, visibleLogicalCpus = availableLogicalCpus, quotaCpus = null, override = null }) {
  if (!Number.isSafeInteger(availableLogicalCpus) || availableLogicalCpus < 1
      || !Number.isSafeInteger(visibleLogicalCpus) || visibleLogicalCpus < 1
      || (quotaCpus !== null && (!Number.isFinite(quotaCpus) || quotaCpus <= 0))) throw new Error('Invalid actual CPU capacity');
  const effectiveLogicalCpus = Math.min(availableLogicalCpus, visibleLogicalCpus,
    quotaCpus === null ? availableLogicalCpus : Math.max(1, Math.floor(quotaCpus)));
  if (override !== null && (!Number.isSafeInteger(override) || override < 1 || override > 256)) throw new Error('Worker override must be an integer1..256');
  return { availableLogicalCpus, visibleLogicalCpus, quotaCpus, effectiveLogicalCpus,
    policy: override === null ? 'two-workers-per-effective-logical-cpu' : 'explicit-worker-override',
    configuredWorkers: override ?? effectiveLogicalCpus * 2, observedWorkerCount: null };
}

export function detectWorkerCapacity(override = null) {
  let quotaCpus = null;
  if (process.platform === 'linux') {
    let quota;
    try { quota = readFileSync('/sys/fs/cgroup/cpu.max', 'utf8').trim().split(/\s+/); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    if (quota) {
      if (quota.length !== 2 || !Number.isFinite(Number(quota[1])) || Number(quota[1]) <= 0) throw new Error('Invalid cgroup CPU quota');
      if (quota[0] !== 'max') quotaCpus = Number(quota[0]) / Number(quota[1]);
    } else {
      try { const amount = Number(readFileSync('/sys/fs/cgroup/cpu/cpu.cfs_quota_us', 'utf8'));
        const period = Number(readFileSync('/sys/fs/cgroup/cpu/cpu.cfs_period_us', 'utf8'));
        if (amount !== -1) { if (!(period > 0)) throw new Error('Invalid legacy CPU quota'); quotaCpus = amount / period; }
      } catch (error) { if (error.code !== 'ENOENT') throw error; }
    }
  }
  return selectWorkerCapacity({ availableLogicalCpus: availableParallelism(), visibleLogicalCpus: cpus().length, quotaCpus, override });
}
