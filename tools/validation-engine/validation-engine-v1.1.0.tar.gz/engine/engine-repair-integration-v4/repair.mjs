import { createHash } from 'node:crypto';
import { lstat, readFile, realpath, open, rename } from 'node:fs/promises';
import { resolve, relative, isAbsolute, sep } from 'node:path';
import { performance } from 'node:perf_hooks';
import { coordinate, preparePlan, resourceKey } from '../engine-controller-priority-v2/controller.mjs';
import { planRetests } from '../engine-controller-priority-v2/retest.mjs';

const HASH = /^[a-f0-9]{64}$/;
export const digestBytes = (bytes) => createHash('sha256').update(bytes).digest('hex');
const check = (ok, message) => { if (!ok) throw new Error(message); };
const same = (a, b) => a && b && ['repository', 'commit', 'tree', 'lockSha256'].every((key) => a[key] === b[key]);
const canonical = (paths) => {
  check(Array.isArray(paths), 'explicit file ownership required');
  const keys = paths.map((path) => resourceKey(path, process.platform !== 'win32'));
  check(new Set(keys).size === keys.length, 'duplicate/aliased ownership');
  return keys;
};
const conflict = (a, b) => a.writes.some((path) => b.reads.includes(path) || b.writes.includes(path))
  || a.reads.some((path) => b.writes.includes(path));
const inside = (root, child) => { const path = relative(root, child); return path && !isAbsolute(path) && path !== '..' && !path.startsWith(`..${sep}`); };

// Callback adaptation of the reviewed queue's atomic reservation/FIFO/bypass
// protocol. Logical locks only: callbacks and the host must obey this ownership.
export async function createRepairQueue({ root, immutableRoot, snapshot, handlers, concurrency = 4, signal, maxRequests = 128 }) {
  const boundary = await realpath(root); const immutable = await realpath(immutableRoot);
  check(boundary !== immutable && !inside(immutable, boundary) && !inside(boundary, immutable), 'repair workspace must be separate from immutable test snapshot');
  check(Number.isInteger(concurrency) && concurrency > 0 && concurrency <= 32, 'bounded repair callback concurrency required');
  check(Number.isInteger(maxRequests) && maxRequests > 0 && maxRequests <= 1024, 'bounded request count required');
  check(snapshot && HASH.test(snapshot.executionEnvironmentSha256), 'verified base environment snapshot required');
  const pathFor = async (key) => {
    const path = resolve(boundary, key); check(inside(boundary, path), 'repair path escaped root');
    const stat = await lstat(path); check(stat.isFile() && !stat.isSymbolicLink(), 'repair input must be an existing regular file');
    check((await realpath(path)) === path, 'repair ancestor aliases forbidden');
    return path;
  };
  const registry = new Map();
  for (const handler of handlers) {
    check(typeof handler.id === 'string' && /^[A-Za-z0-9._-]+$/.test(handler.id) && !registry.has(handler.id), 'unique reviewed handler ID required');
    check(handler.rootReviewed === true && HASH.test(handler.approvalSha256) && typeof handler.propose === 'function', 'only reviewed/preapproved patch callbacks allowed');
    const reads = canonical(handler.reads); const writes = canonical(handler.writes);
    check(writes.length > 0 && writes.length <= 64, 'bounded declared writer transaction required');
    check(writes.every((path) => !/(?:^|\/)(?:tests?|__tests__)\/|\.(?:test|spec)\./i.test(path)), 'automatic queue cannot edit test/assertion payloads');
    for (const path of new Set([...reads, ...writes])) {
      check(HASH.test(snapshot.sourceHashes[path]), 'every callback input needs base snapshot digest');
      await pathFor(path);
    }
    registry.set(handler.id, { ...handler, reads: reads.filter((p) => !writes.includes(p)), writes });
  }
  const pending = []; const active = new Map(); const promises = []; const results = [];
  let sequence = 0; let waiters = []; let tainted = false;
  const stats = { requestsQueued: 0, callbacksStarted: 0, applied: 0, failed: 0, rejectedStale: 0,
    reviewRequired: 0, cancelled: 0, lockBlocked: 0, peakActiveCallbacks: 0, configuredCallbacks: concurrency,
    childProcessesSpawned: 0, osThreadCount: null };
  const notify = () => { for (const waiter of waiters.splice(0)) waiter(); };
  const run = async (job) => {
    const began = performance.now(); const output = { id: job.id, request: job.request, handler: job.handler.id,
      approvalSha256: job.handler.approvalSha256, status: 'failed', changedFiles: [],
      partiallyApplied: false, queueWaitMs: began - job.queuedAt, error: null };
    let stagedCount = 0;
    try {
      if (signal?.aborted) { output.status = 'cancelled'; return; }
      if (tainted) { output.status = 'review-required'; output.error = 'candidate tainted by earlier partial transaction'; return; }
      const inputs = {};
      for (const key of new Set([...job.handler.reads, ...job.handler.writes])) {
        const bytes = await readFile(await pathFor(key));
        if (digestBytes(bytes) !== job.request.baseHashes[key]) {
          if (!results.some((entry) => entry.status === 'applied' && entry.changedFiles.some((edit) => edit.path === key && edit.afterSha256 === digestBytes(bytes)))) tainted = true;
          output.status = 'rejected-stale'; output.error = `stale base: ${key}`; return;
        }
        inputs[key] = Buffer.from(bytes);
      }
      stats.callbacksStarted++;
      const proposal = await job.handler.propose(Object.freeze({ request: structuredClone(job.request), inputs, signal }));
      check(Array.isArray(proposal?.edits) && proposal.edits.length > 0 && proposal.edits.length <= job.handler.writes.length, 'explicit compatible transaction edits required');
      const edits = []; const seen = new Set();
      let replacementBytes = 0;
      for (const edit of proposal.edits) {
        const key = resourceKey(edit.path, process.platform !== 'win32');
        check(job.handler.writes.includes(key) && !seen.has(key), 'undeclared/duplicate output; unknown patches are not merged');
        seen.add(key); check(Buffer.isBuffer(edit.bytes) || edit.bytes instanceof Uint8Array, 'exact replacement bytes required');
        const bytes = Buffer.from(edit.bytes);
        replacementBytes += bytes.length;
        check(bytes.length <= 16 * 1024 ** 2 && replacementBytes <= 64 * 1024 ** 2, 'bounded reviewed replacement-byte budget exceeded');
        check(edit.baseSha256 === job.request.baseHashes[key] && HASH.test(edit.afterSha256) && digestBytes(bytes) === edit.afterSha256, 'patch base/after hashes mismatch');
        check(edit.afterSha256 !== edit.baseSha256, 'no-op is not a repair');
        edits.push({ key, bytes, afterSha256: edit.afterSha256, path: await pathFor(key) });
      }
      // Verify every declared read again after the callback; it never receives
      // source-write authority. Unknown external writers remain a host violation.
      for (const [key, base] of Object.entries(job.request.baseHashes)) {
        if (digestBytes(await readFile(await pathFor(key))) !== base) { tainted = true; output.status = 'rejected-stale'; output.error = `source changed while proposing: ${key}`; return; }
      }
      const staged = [];
      for (const edit of edits) {
        const temporary = `${edit.path}.repair-v4-${process.pid}-${job.id}`;
        const handle = await open(temporary, 'wx', (await lstat(edit.path)).mode & 0o777);
        stagedCount++;
        try { await handle.writeFile(edit.bytes); await handle.sync(); } finally { await handle.close(); }
        staged.push({ ...edit, temporary });
      }
      for (const edit of staged) {
        if (signal?.aborted) throw new Error('cancelled before/within transaction commit');
        check(digestBytes(await readFile(await pathFor(edit.key))) === job.request.baseHashes[edit.key], 'stale base before atomic replacement');
        await rename(edit.temporary, edit.path); // Atomic replacement PER FILE, not across multiple files.
        output.changedFiles.push({ path: edit.key, beforeSha256: job.request.baseHashes[edit.key], afterSha256: edit.afterSha256 });
        check(digestBytes(await readFile(edit.path)) === edit.afterSha256, 'replacement readback mismatch');
      }
      output.status = 'applied';
    } catch (error) {
      output.error = error.message; output.partiallyApplied = output.changedFiles.length > 0;
      if (output.partiallyApplied || stagedCount) tainted = true; // Retained temporary evidence also prevents a clean freeze.
    } finally {
      output.wallMs = performance.now() - began; results.push(output);
      const counter = { applied: 'applied', failed: 'failed', 'rejected-stale': 'rejectedStale', 'review-required': 'reviewRequired', cancelled: 'cancelled' }[output.status];
      stats[counter]++; active.delete(job.id); job.resolve(output); notify(); pump();
    }
  };
  function pump() {
    for (let index = 0; index < pending.length && active.size < concurrency; index++) {
      const job = pending[index];
      if ([...active.values()].some((other) => conflict(job.handler, other.handler))
          || pending.slice(0, index).some((other) => conflict(job.handler, other.handler))) {
        if (!job.blocked) { job.blocked = true; stats.lockBlocked++; } continue;
      }
      pending.splice(index--, 1); active.set(job.id, job);
      stats.peakActiveCallbacks = Math.max(stats.peakActiveCallbacks, active.size);
      void run(job);
    }
  }
  return Object.freeze({
    enqueue: (request) => {
      check(stats.requestsQueued < maxRequests, 'repair request limit reached');
      check(request && same(request.candidate, snapshot.candidate) && typeof request.failedUnitId === 'string'
        && HASH.test(request.failureEvidenceSha256), 'bound failure evidence required');
      const handler = registry.get(request.handlerId);
      if (!handler) {
        const output = { id: `repair-${++sequence}`, request: structuredClone(request), status: 'review-required', error: 'no preapproved repair callback', changedFiles: [] };
        stats.requestsQueued++; stats.reviewRequired++; results.push(output); return Promise.resolve(output);
      }
      const baseHashes = Object.fromEntries([...new Set([...handler.reads, ...handler.writes])].map((path) => [path, snapshot.sourceHashes[path]]));
      const id = `repair-${++sequence}`; stats.requestsQueued++;
      const promise = new Promise((accept) => { pending.push({ id, handler, request: { ...structuredClone(request), baseHashes }, queuedAt: performance.now(), resolve: accept }); });
      promises.push(promise); pump(); return promise;
    },
    drain: async () => {
      while (active.size || pending.length) await new Promise((accept) => waiters.push(accept));
      await Promise.all(promises);
      return { ok: !tainted && results.every((result) => result.status === 'applied'), tainted, stats: { ...stats }, results: structuredClone(results) };
    },
  });
}

// Bind failures to actual queue requests without blocking independent checks.
// Frozen read snapshot stays immutable; callbacks modify a SEPARATE candidate.
export async function runRepairCycle({ plan: input, snapshot, immutableRoot, repairRoot, executor,
  handlers, handlerByUnit = {}, freezeCandidate, testSlots = 20, repairSlots = 4, signal }) {
  const plan = preparePlan(input);
  check(plan.maxSlots === testSlots && testSlots + repairSlots <= 128, 'explicit test+repair admission budgets required');
  check(same(plan.candidate, snapshot.candidate) && plan.executionEnvironmentSha256 === snapshot.executionEnvironmentSha256, 'exact initial snapshot required');
  check(plan.units.every((unit) => unit.writes.length === 0), 'test snapshot units must not write source');
  const queue = await createRepairQueue({ root: repairRoot, immutableRoot, snapshot, handlers, concurrency: repairSlots, signal });
  const requests = new Map();
  const submit = (id, failure) => {
    if (requests.has(id)) return;
    const request = { failedUnitId: id, candidate: plan.candidate, runId: plan.runId,
      failureEvidenceSha256: HASH.test(failure.evidenceSha256) ? failure.evidenceSha256 : digestBytes(Buffer.from(JSON.stringify(failure))),
      failure: structuredClone(failure), handlerId: handlerByUnit[id] ?? null };
    requests.set(id, request); void queue.enqueue(request);
  };
  const initial = await coordinate(plan, { execute: true, signal, executor: async (unit, context, childSignal) => {
    const receipt = await executor(unit, context, childSignal);
    if (receipt?.status === 'failed' && same(receipt.candidate, plan.candidate) && receipt.runId === plan.runId) submit(unit.id, receipt);
    return receipt;
  } });
  for (const failure of initial.results.filter((result) => result.status === 'failed')) submit(failure.id, failure);
  const repairs = await queue.drain();
  const result = { schemaVersion: 4, initial, repairRequests: [...requests.values()], repairs, retestPlan: null,
    retest: null, retainedGreen: [], finalUnits: initial.results, ok: initial.ok && repairs.results.length === 0,
    originalRunPassed: initial.ok, releaseGatePassed: false,
    budget: { testSlots, repairCallbackSlots: repairSlots, totalAdmittedSlots: testSlots + repairSlots, measuredOsThreads: null },
    limits: ['Review callbacks are cooperative, not a sandbox or cross-process locks.',
      'Atomic replacement is per file; failed partial batches taint the private candidate.',
      'Host freezes/verifies a fresh immutable candidate and owns real test execution.',
      'Retained-green is proven reuse, not a newly executed pass or release gate.',
      'No assertion edits, automatic AI fixer, unbounded retry or compilation.'] };
  if (repairs.tainted || !repairs.results.some((repair) => repair.status === 'applied') || signal?.aborted) return result;
  check(typeof freezeCandidate === 'function', 'host-reviewed immutable candidate freeze adapter required');
  const next = await freezeCandidate({ previousSnapshot: snapshot, repairs, repairRoot });
  const nextPlan = preparePlan(next.plan);
  check(nextPlan.runId !== plan.runId && same(nextPlan.candidate, next.snapshot.candidate), 'fresh run/candidate snapshot required');
  check(nextPlan.candidate.commit !== plan.candidate.commit || nextPlan.candidate.tree !== plan.candidate.tree, 'applied source repair requires NEW candidate identity');
  check(nextPlan.units.length === plan.units.length && JSON.stringify(nextPlan.units.map((u) => u.id)) === JSON.stringify(plan.units.map((u) => u.id)), 'retained/retest coverage inventory must be unchanged');
  check(JSON.stringify(nextPlan.units.map((u) => [u.id, u.files])) === JSON.stringify(plan.units.map((u) => [u.id, u.files])), 'repair cannot replace or drop selected test payloads');
  check(await realpath(next.immutableRoot) !== await realpath(repairRoot), 'retests must read a fresh immutable snapshot, not mutable repair workspace');
  check(await realpath(next.immutableRoot) !== await realpath(immutableRoot), 'repaired candidate requires a new immutable source root');
  for (const repair of repairs.results.filter((entry) => entry.status === 'applied')) {
    for (const edit of repair.changedFiles) check(next.snapshot.sourceHashes[edit.path] === edit.afterSha256, 'fresh snapshot omits accepted replacement bytes');
  }
  const selection = planRetests(nextPlan, { runId: plan.runId, snapshot, results: Object.fromEntries(initial.results.map((r) => [r.id, r])) }, next.snapshot);
  result.retestPlan = selection;
  const retained = new Set(selection.retainedUnitIds); result.retainedGreen = selection.units.filter((unit) => retained.has(unit.id));
  const lanes = nextPlan.lanes.map((lane) => ({ ...structuredClone(lane), prerequisites: [...lane.prerequisites] }));
  const units = nextPlan.units.filter((unit) => !retained.has(unit.id)).map((unit) => structuredClone(unit));
  const selectedLanes = new Set(units.map((unit) => unit.lane));
  const proveRetained = (ids, lane) => {
    check(ids.length > 0 && ids.every((id) => retained.has(id)), 'removed dependency is not proven green');
    const proofs = ids.map((id) => selection.units.find((unit) => unit.id === id));
    const evidenceSha256 = digestBytes(Buffer.from(JSON.stringify(proofs)));
    const id = `retained-${evidenceSha256.slice(0, 16)}`;
    if (!lane.prerequisites.some((entry) => entry.id === id)) lane.prerequisites.push({ id, status: 'ready', evidenceSha256 });
  };
  for (const unit of units) {
    const removed = unit.dependsOn.filter((id) => retained.has(id));
    if (removed.length) proveRetained(removed, lanes.find((lane) => lane.id === unit.lane));
    unit.dependsOn = unit.dependsOn.filter((id) => !retained.has(id));
  }
  for (const lane of lanes) {
    for (const removed of lane.dependsOn.filter((id) => !selectedLanes.has(id))) proveRetained(nextPlan.units.filter((unit) => unit.lane === removed).map((unit) => unit.id), lane);
    lane.dependsOn = lane.dependsOn.filter((id) => selectedLanes.has(id));
  }
  const retestInput = { ...structuredClone(nextPlan), units, lanes: lanes.filter((lane) => selectedLanes.has(lane.id)) };
  result.retest = await coordinate(retestInput, { execute: true, signal, executor: next.executor });
  const byId = new Map(result.retest.results.map((unit) => [unit.id, unit]));
  result.finalUnits = nextPlan.units.map((unit) => byId.get(unit.id) ?? { id: unit.id, status: 'retained-green', executed: false,
    retainedFromRunId: plan.runId, proof: selection.units.find((entry) => entry.id === unit.id) });
  result.ok = repairs.ok && result.retest.ok && result.finalUnits.every((unit) => ['passed', 'retained-green', 'not-selected'].includes(unit.status));
  return result;
}
