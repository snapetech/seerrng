import { digestBytes } from './repair.mjs';
import { preparePlan, resourceKey } from '../engine-controller-priority-v2/controller.mjs';

const SHA = /^[a-f0-9]{64}$/;
const check = (value, message) => { if (!value) throw new Error(message); };
const same = (a, b) => a && b && ['repository', 'commit', 'tree', 'lockSha256'].every((key) => a[key] === b[key]);
const idFor = (path) => `vitest-${digestBytes(Buffer.from(path)).slice(0, 24)}`;
const filePath = (name) => {
  check(typeof name === 'string' && name.startsWith('/app/'), 'exact /app report path required');
  return resourceKey(name.slice('/app/'.length), true);
};

// Report mapping is not a newly executed test. The report bytes and preservation
// evidence are supplied by the reviewed host, never fabricated here.
export function mapCanonicalReport({ plan: input, ownerId = 'canonical-units', ownerReceipt,
  reportBytes, snapshot, sourcePreservationSha256, sourcePreservationProof = null,
  caseLedgerBytes = null, caseLedgerSha256 = null, contracts = {}, allowedSkips = [] }) {
  const plan = preparePlan(input); const owner = plan.units.find((unit) => unit.id === ownerId);
  check(owner && owner.files.length > 0 && Buffer.isBuffer(reportBytes), 'bound canonical owner and actual report bytes required');
  check(ownerReceipt?.runId === plan.runId && same(ownerReceipt.candidate, plan.candidate)
    && same(snapshot?.candidate, plan.candidate) && snapshot.executionEnvironmentSha256 === plan.executionEnvironmentSha256
    && ownerReceipt.executionEnvironmentSha256 === plan.executionEnvironmentSha256
    && SHA.test(snapshot.executionEnvironmentSha256) && SHA.test(sourcePreservationSha256), 'exact owner/source/environment preservation evidence required');
  const reportSha256 = digestBytes(reportBytes); const report = JSON.parse(reportBytes);
  check(ownerReceipt.reportSha256 === reportSha256, 'actual report bytes are not bound by owner receipt');
  check(Array.isArray(report.testResults), 'actual Vitest file report required');
  const actualPaths = report.testResults.map((file) => filePath(file.name));
  check(new Set(actualPaths).size === actualPaths.length && JSON.stringify([...actualPaths].sort()) === JSON.stringify([...owner.files].sort()), 'report discovery differs from exact selected file inventory');
  const globalError = (report.numUnhandledErrors ?? 0) !== 0
    || ['errors', 'unhandledErrors'].some((key) => report[key] !== undefined && (!Array.isArray(report[key]) || report[key].length > 0))
    || (report.numFailedTests === 0 && !report.testResults.some((file) => file.status === 'failed')
      && (report.success !== true || ownerReceipt.exitCode !== 0));
  const lifecycleVerified = ownerReceipt.childrenStopped === true && ownerReceipt.leftoverGroup === false
    && ownerReceipt.timedOut === false && ownerReceipt.aborted === false && ownerReceipt.signal === null
    && ownerReceipt.childIdentity?.verifiedDetachedGroup === true && [0, 1].includes(ownerReceipt.exitCode);
  const preservation = sourcePreservationProof?.receipt;
  const sourcePreservationVerified = Boolean(sourcePreservationProof?.evidenceSha256 === sourcePreservationSha256
    && same(preservation?.candidate, plan.candidate) && preservation.postInputHashesVerified === true
    && preservation.executionEnvironmentSha256 === snapshot.executionEnvironmentSha256
    && SHA.test(snapshot.sourceManifestSha256) && preservation.sourceManifestSha256 === snapshot.sourceManifestSha256
    && preservation.fileCount === Object.keys(snapshot.sourceHashes).length);
  let ledger = null;
  if (Buffer.isBuffer(caseLedgerBytes) && SHA.test(caseLedgerSha256)) {
    check(digestBytes(caseLedgerBytes) === caseLedgerSha256, 'expected case-ledger bytes differ');
    const parsed = JSON.parse(caseLedgerBytes);
    if (parsed.complete === true && same(parsed.candidate, plan.candidate)
        && parsed.executionEnvironmentSha256 === snapshot.executionEnvironmentSha256 && Array.isArray(parsed.files)) {
      check(new Set(parsed.files.map((file) => file.path)).size === parsed.files.length, 'duplicate expected ledger file');
      for (const file of parsed.files) {
        resourceKey(file.path, true);
        check(SHA.test(file.payloadSha256) && Array.isArray(file.names) && file.names.every((name) => typeof name === 'string')
          && new Set(file.names).size === file.names.length, 'invalid/duplicate expected case identity');
      }
      ledger = new Map(parsed.files.map((file) => [file.path, file]));
    }
  }
  const closure = (paths) => {
    const reached = new Set(); let complete = true;
    const visit = (path) => {
      if (reached.has(path)) return; reached.add(path);
      if (!SHA.test(snapshot.sourceHashes[path]) || !Array.isArray(snapshot.dependencies?.[path])) { complete = false; return; }
      snapshot.dependencies[path].forEach(visit);
    };
    paths.forEach(visit); return { complete, paths: [...reached].sort() };
  };
  const files = report.testResults.map((file) => {
    const path = filePath(file.name); check(SHA.test(snapshot.sourceHashes[path]), 'test payload hash missing from snapshot');
    check(Array.isArray(file.assertionResults), 'actual named case results required');
    const cases = { passed: 0, failed: 0, skipped: 0 }; const caseIdentities = [];
    for (const test of file.assertionResults) {
      check(typeof test.fullName === 'string' && ['passed', 'failed', 'pending', 'skipped', 'todo'].includes(test.status), 'unknown case name/status');
      cases[test.status === 'passed' ? 'passed' : test.status === 'failed' ? 'failed' : 'skipped']++;
      caseIdentities.push({ file: path, name: test.fullName, status: test.status });
    }
    check(new Set(caseIdentities.map((test) => test.name)).size === caseIdentities.length, 'duplicate exact file/fullName case identity');
    const expectedCases = ledger?.get(path);
    const caseInventoryVerified = Boolean(expectedCases?.payloadSha256 === snapshot.sourceHashes[path]
      && JSON.stringify([...expectedCases.names].sort()) === JSON.stringify(caseIdentities.map((test) => test.name).sort()));
    const skipsReviewed = caseIdentities.filter((test) => !['passed', 'failed'].includes(test.status))
      .every((test) => allowedSkips.some((skip) => skip.file === path && skip.name === test.name));
    const declared = contracts[path]; const inputs = closure(declared?.paths ?? [path]);
    const contractComplete = declared?.complete === true && SHA.test(declared.contractSha256)
      && declared.paths.includes(path) && inputs.complete;
    const assertionFailure = cases.failed > 0 || file.status === 'failed';
    const activeCases = cases.passed + cases.failed;
    const status = !lifecycleVerified || !sourcePreservationVerified || globalError ? 'review-required'
      : assertionFailure ? 'failed' : !caseInventoryVerified || !skipsReviewed || !caseIdentities.length ? 'review-required'
      : activeCases === 0 ? 'conditional-skip' : 'passed';
    const evidenceSha256 = digestBytes(Buffer.from(JSON.stringify({ reportSha256, sourcePreservationSha256, path, file })));
    return { id: idFor(path), path, payloadSha256: snapshot.sourceHashes[path], status, assertionFailure,
      runId: plan.runId, candidate: plan.candidate, executionEnvironmentSha256: snapshot.executionEnvironmentSha256,
      evidenceSha256, sourcePreservationSha256, reportSha256, cases, caseIdentities, caseInventoryVerified,
      contractSha256: contractComplete ? declared.contractSha256 : null,
      inputHashes: contractComplete ? Object.fromEntries(inputs.paths.map((key) => [key, snapshot.sourceHashes[key]])) : null,
      validationInputs: contractComplete ? structuredClone(declared) : { complete: false, paths: [path] },
      eligibleForRetention: status === 'passed' && caseInventoryVerified && contractComplete && snapshot.impactComplete === true,
      executedByMapping: false, importedActualReport: true };
  });
  const total = files.reduce((sum, file) => sum + Object.values(file.cases).reduce((a, b) => a + b, 0), 0);
  check(total === report.numTotalTests && files.reduce((sum, file) => sum + file.cases.failed, 0) === report.numFailedTests
    && files.reduce((sum, file) => sum + file.cases.passed, 0) === report.numPassedTests, 'actual report/case totals disagree');
  return { runId: plan.runId, candidate: plan.candidate, reportSha256, files, actualReportedFileCount: files.length,
    actualReportedCases: total, lifecycleVerified, globalError, sourcePreservationSha256, sourcePreservationVerified,
    caseLedgerSha256, caseInventoryVerified: files.every((file) => file.caseInventoryVerified), actualTestsExecutedByMapping: 0,
    infrastructureReviewRequired: !lifecycleVerified || !sourcePreservationVerified || globalError,
    failedFiles: files.filter((file) => file.assertionFailure).map((file) => file.path) };
}

// Real queue API calls, not a hypothetical request list. Missing approvals remain
// unresolved. A failed owner lifecycle requires a separate reviewed runner fix.
export async function queueCanonicalFailures(queue, mapped, handlerByFile = {}) {
  check(typeof queue?.enqueue === 'function', 'actual reviewed repair queue required');
  if (mapped.infrastructureReviewRequired) return { requests: [], pendingFiles: mapped.failedFiles,
    infrastructureReviewRequired: true, infrastructureFailureIsNotAnAppRepair: true, actualTestsExecuted: 0 };
  const pending = [];
  for (const file of mapped.files.filter((entry) => entry.assertionFailure)) {
    const request = { failedUnitId: file.id, candidate: mapped.candidate, runId: mapped.runId,
      failureEvidenceSha256: file.evidenceSha256, handlerId: handlerByFile[file.path] ?? null,
      failedFile: file.path, failure: structuredClone(file) };
    pending.push(queue.enqueue(request).then((outcome) => ({ request, outcome })));
  }
  const requests = await Promise.all(pending);
  return { requests, infrastructureReviewRequired: mapped.infrastructureReviewRequired,
    infrastructureFailureIsNotAnAppRepair: true, actualTestsExecuted: 0 };
}

export function logicalCanonicalPlan(input, mapped) {
  const plan = preparePlan(input); const owner = plan.units.find((unit) => unit.id === 'canonical-units');
  check(owner && mapped.runId === plan.runId && same(mapped.candidate, plan.candidate), 'matching exact mapped owner required');
  const fileIds = mapped.files.map((file) => file.id);
  const units = plan.units.flatMap((unit) => unit.id === owner.id ? mapped.files.map((file) => ({
    id: file.id, lane: owner.lane, slots: 1, reads: file.validationInputs.complete ? file.validationInputs.paths : [file.path],
    writes: [], files: [file.path], dependsOn: owner.dependsOn, validationInputs: file.validationInputs,
    payload: { canonicalFile: file.path, sha256: file.payloadSha256 },
  })) : [{ ...structuredClone(unit), dependsOn: unit.dependsOn.flatMap((id) => id === owner.id ? fileIds : [id]) }]);
  return { plan: preparePlan({ ...structuredClone(plan), units }),
    previousFileResults: Object.fromEntries(mapped.files.map((file) => [file.id, {
      ...structuredClone(file), status: file.eligibleForRetention ? 'passed' : file.status === 'failed' ? 'failed' : 'review-required',
    }])), executionAllowedByExpansion: false, actualTestsExecuted: 0 };
}

// One native subset invocation, never one Vitest startup per file. The injected
// host must generate a sealed subset config, enforce lifecycle/source guards,
// and preserve its actual report. This function creates no process or source.
export async function executeExactCanonicalSubset({ logicalPlan: input, selection, snapshot,
  sourceManifestSha256, executeBoundSubset, workerBudget = 20, allowedSkips = [], caseLedgerBytes = null, caseLedgerSha256 = null }) {
  const plan = preparePlan(input);
  check(selection.runId === plan.runId && same(selection.candidate, plan.candidate) && same(snapshot.candidate, plan.candidate), 'exact fresh retest selection required');
  check(SHA.test(sourceManifestSha256) && sourceManifestSha256 === snapshot.sourceManifestSha256 && SHA.test(plan.executionEnvironmentSha256)
    && plan.executionEnvironmentSha256 === snapshot.executionEnvironmentSha256, 'actual source/environment evidence required');
  check(Number.isInteger(workerBudget) && workerBudget >= 1 && workerBudget <= Math.min(20, plan.maxSlots) && typeof executeBoundSubset === 'function', 'bounded native subset host adapter required');
  const selected = new Set(selection.retestUnitIds);
  const units = plan.units.filter((unit) => selected.has(unit.id) && unit.payload?.canonicalFile);
  check(units.length > 0, 'empty subset is not new test execution');
  const files = units.map((unit) => {
    check(unit.files.length === 1 && unit.files[0] === unit.payload.canonicalFile && SHA.test(snapshot.sourceHashes[unit.files[0]]), 'exact per-file source identity required');
    return { path: unit.files[0], sha256: snapshot.sourceHashes[unit.files[0]] };
  });
  check(new Set(files.map((file) => file.path)).size === files.length, 'duplicate subset payload');
  const scope = { runId: plan.runId, candidate: plan.candidate, executionEnvironmentSha256: plan.executionEnvironmentSha256,
    sourceManifestSha256, files, workers: Math.min(workerBudget, files.length), withinFileConcurrent: false, isolated: true,
    retainedFilesNotExecuted: selection.retainedUnitIds, subsetSha256: digestBytes(Buffer.from(JSON.stringify(files))) };
  const returned = await executeBoundSubset(Object.freeze(scope));
  check(returned?.subsetSha256 === scope.subsetSha256, 'host executed a different subset');
  const owner = { id: 'canonical-subset', lane: 'canonical-subset', slots: scope.workers, reads: files.map((file) => file.path), writes: [], files: files.map((file) => file.path) };
  const subsetPlan = { ...structuredClone(plan), lanes: [{ id: 'canonical-subset', kind: 'test' }], units: [owner] };
  const contracts = Object.fromEntries(units.map((unit) => [unit.files[0], unit.validationInputs]));
  const mapped = mapCanonicalReport({ plan: subsetPlan, ownerId: owner.id, ownerReceipt: returned.receipt,
    reportBytes: returned.reportBytes, snapshot, sourcePreservationSha256: returned.sourcePreservationSha256,
    sourcePreservationProof: returned.sourcePreservationProof, caseLedgerBytes, caseLedgerSha256, contracts, allowedSkips });
  return { scope, mapped, actualSubsetInvocations: 1, actualReportedFileCount: mapped.files.length,
    selectedFileCount: files.length, fullEngineAcceptance: false,
    acceptancePending: !mapped.lifecycleVerified || !mapped.sourcePreservationVerified || !mapped.caseInventoryVerified,
    passed: mapped.lifecycleVerified && mapped.sourcePreservationVerified && mapped.caseInventoryVerified
      && !mapped.globalError && mapped.files.every((file) => ['passed', 'conditional-skip'].includes(file.status)) };
}
