import test from 'node:test';
import assert from 'node:assert/strict';
import {
  resolveOperatorGithubLogin,
  selectWorkerCapacity,
} from './cpu-capacity.mjs';

test('ordinary operators default to one fewer worker than effective logical CPUs', () => {
  const result = selectWorkerCapacity({ availableLogicalCpus: 12 });
  assert.equal(result.effectiveLogicalCpus, 12);
  assert.equal(result.configuredWorkers, 11);
  assert.equal(result.policy, 'one-worker-less-than-effective-logical-cpus');
  assert.equal(result.operatorGithubLogin, null);
});

test('the approved GitHub operator automatically receives two workers per effective logical CPU', () => {
  const result = selectWorkerCapacity({
    availableLogicalCpus: 32,
    operatorGithubLogin: 'johncronk79',
  });
  assert.equal(result.configuredWorkers, 64);
  assert.equal(result.policy, 'two-workers-per-effective-logical-cpu-for-approved-operator');
  assert.equal(result.operatorGithubLogin, 'JohnCronk79');
});

test('automatic policies respect visible and cgroup CPU limits', () => {
  const ordinary = selectWorkerCapacity({
    availableLogicalCpus: 32,
    visibleLogicalCpus: 16,
    quotaCpus: 12.9,
  });
  const approved = selectWorkerCapacity({
    availableLogicalCpus: 32,
    visibleLogicalCpus: 16,
    quotaCpus: 12.9,
    operatorGithubLogin: 'JohnCronk79',
  });
  assert.equal(ordinary.effectiveLogicalCpus, 12);
  assert.equal(ordinary.configuredWorkers, 11);
  assert.equal(approved.configuredWorkers, 24);
});

test('the ordinary one-CPU floor remains one worker', () => {
  assert.equal(selectWorkerCapacity({ availableLogicalCpus: 1 }).configuredWorkers, 1);
});

test('an explicit worker override remains authoritative', () => {
  const result = selectWorkerCapacity({
    availableLogicalCpus: 12,
    override: 7,
    operatorGithubLogin: 'JohnCronk79',
  });
  assert.equal(result.configuredWorkers, 7);
  assert.equal(result.policy, 'explicit-worker-override');
});

test('GitHub Actions actors and ordinary Git identity resolve without credentials', () => {
  assert.equal(resolveOperatorGithubLogin({
    environment: { GITHUB_ACTOR: 'JohnCronk79' },
  }), 'JohnCronk79');
  assert.equal(resolveOperatorGithubLogin({
    gitConfig: (key) => key === 'github.user' ? 'JohnCronk79' : null,
  }), 'JohnCronk79');
  assert.equal(resolveOperatorGithubLogin({
    gitConfig: (key) => key === 'user.email'
      ? '124496464+JohnCronk79@users.noreply.github.com'
      : key === 'user.name' ? 'John Cronk' : null,
  }), 'JohnCronk79');
  assert.equal(resolveOperatorGithubLogin({
    gitConfig: (key) => key === 'user.name' ? 'JohnCronk79' : null,
  }), 'JohnCronk79');
  assert.equal(resolveOperatorGithubLogin({
    environment: { GITHUB_ACTOR: 'snapetech' },
    gitConfig: () => null,
  }), null);
  assert.equal(resolveOperatorGithubLogin({
    environment: { GITHUB_ACTOR: 'snapetech' },
    gitConfig: () => 'JohnCronk79',
  }), null);
});
