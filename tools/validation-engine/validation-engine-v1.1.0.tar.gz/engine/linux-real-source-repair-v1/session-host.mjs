import { realpath } from 'node:fs/promises';
import { preparePlan } from '../engine-controller-priority-v2/controller.mjs';
import { verifyWorker } from './cli.mjs';
import { readPinned, recordNew, verifySource, freezeActualSource, sameCandidate } from './filesystem-export-v2.mjs';

const SHA=/^[a-f0-9]{64}$/;
const check=(ok,m)=>{if(!ok)throw Error(m);};
async function contextInputs(request,context){
  const c=context.hostConfiguration;
  check(c?.rootReviewed===true&&SHA.test(context.packetSha256)&&SHA.test(context.recipeManifestSha256)&&request.workingRoot===c.workingRoot&&request.authority.expectedWorkingRoot===c.workingRoot&&request.authority.sourceIdentity===c.workingVolume,'Exact selected session working-volume/context authority required');
  check(c.allOtherWorkingVolumeWritersExcluded===true&&SHA.test(c.writerAdmissionEvidenceSha256),'Actual exclusive working-volume admission required');
  await verifyWorker(c);
  const manifestBytes=await readPinned(c.sourceManifestPath,c.sourceManifestSha256),manifest=JSON.parse(manifestBytes);
  check(sameCandidate(manifest,c.candidate)&&manifest.fileCount===c.expectedFileCount,'Exact last-run source manifest required');
  const cloneBytes=await readPinned(c.cloneReceiptPath,c.cloneReceiptSha256),clone=JSON.parse(cloneBytes);
  check(clone.passed===true&&sameCandidate(clone.candidate,c.candidate)&&clone.workingVolume===c.workingVolume&&clone.sourceVolume===c.baselineVolume,'Actual same dedicated volume clone receipt required');
  const journal=await realpath(context.journalRoot);check(journal.startsWith(c.evidenceRoot+'/'),'Journal must be private exclusive evidence descendant');
  return{c,manifest};
}

export async function verifyWorkingAuthority(request,context){
  const{c,manifest}=await contextInputs(request,context);
  check(sameCandidate(request.snapshot.candidate,c.candidate)&&Object.keys(request.snapshot.sourceHashes).length===manifest.fileCount&&manifest.files.every(f=>request.snapshot.sourceHashes[f.path]===f.sha256),'Session frozen baseline differs from actual clone');
  const source=await verifySource(c.workingRoot,manifest),original=await verifySource(c.baselineRoot,manifest,{allowRootMountNames:c.baselineRootMountNames});
  const proof={purpose:'actual-working-volume-exclusive-authority-before-repair',sourceIdentity:c.workingVolume,workingRoot:c.workingRoot,exclusiveWriterOwner:true,workerId:c.workerId,workerInspectSha256:c.workerInspectSha256,writerAdmissionEvidenceSha256:c.writerAdmissionEvidenceSha256,cloneReceiptSha256:c.cloneReceiptSha256,candidate:c.candidate,source,original};
  const receipt=await recordNew(context.journalRoot,'actual-working-authority.json',proof);return{...proof,actualReceiptSha256:receipt.sha256};
}

export async function freezeCandidate(request,context){
  const{c,manifest}=await contextInputs(request,context);
  check(request.actualChanges.ok===true&&request.actualChanges.tainted===false&&sameCandidate(request.previousSnapshot.candidate,c.candidate),'Only clean actual same-base repair wave can freeze');
  const edits=request.actualChanges.results.filter(r=>r.status==='applied').flatMap(r=>r.changedFiles);
  const frozen=await freezeActualSource(c,manifest,edits);
  const manifestReceipt=await recordNew(context.journalRoot,'source-manifest.repaired.json',frozen.manifest);
  const originalMetadata=JSON.parse(await readPinned(c.metadataManifestPath,c.metadataManifestSha256));
  const metadata={schema:1,representation:'base-commit-with-actual-working-index-tree',repository:c.candidate.repository,commit:c.candidate.commit,tree:frozen.candidate.tree,baseTree:c.candidate.tree,sourceManifestSha256:manifestReceipt.sha256,tags:originalMetadata.tags,files:frozen.frozenMetadataFiles};
  const metadataReceipt=await recordNew(context.journalRoot,'git-metadata.repaired.json',metadata);
  check(typeof c.nextRunId==='string'&&c.nextRunId!==request.planningPlan.runId&&SHA.test(c.nextExecutionEnvironmentSha256),'Actual reviewed new run/environment identity required');
  const plan=structuredClone(request.planningPlan);plan.runId=c.nextRunId;plan.candidate=frozen.candidate;plan.executionEnvironmentSha256=c.nextExecutionEnvironmentSha256;
  for(const input of plan.guardInputs??[]){check(frozen.sourceHashes[input.path],'Guard not present in full frozen manifest');input.sha256=frozen.sourceHashes[input.path];}
  for(const unit of plan.units){
    for(const input of unit.payload?.fileInputs??[]){check(frozen.sourceHashes[input.path],'Unit payload not present in new frozen manifest');input.sha256=frozen.sourceHashes[input.path];}
    if(unit.payload?.sha256){check(unit.files.length===1&&frozen.sourceHashes[unit.files[0]],'Logical canonical file needs exact payload');unit.payload.sha256=frozen.sourceHashes[unit.files[0]];}
  }
  preparePlan(plan);
  // No new complete import/dependency graph was analysed here. Broad pending
  // revalidation is required; stale original closures cannot retain green.
  const snapshot={candidate:frozen.candidate,sourceManifestSha256:manifestReceipt.sha256,sourceHashes:frozen.sourceHashes,executionEnvironmentSha256:c.nextExecutionEnvironmentSha256,dependencies:{},impactComplete:false};
  const planReceipt=await recordNew(context.journalRoot,'repaired-logical-plan.json',plan);
  const snapshotReceipt=await recordNew(context.journalRoot,'repaired-snapshot.json',snapshot);
  const exportReceipt=await recordNew(context.journalRoot,'actual-freeze-export.json',{...frozen,sourceManifestReceipt:manifestReceipt,metadataReceipt,planReceipt,snapshotReceipt,requiresNewReadOnlyConsumer:true,actualTestsExecuted:0});
  return{plan,snapshot,immutableRoot:c.frozenRoot,fullWorkingManifestVerified:true,freezeReceiptSha256:exportReceipt.sha256,metadataReceipt,sourceManifestReceipt:manifestReceipt,frozenGitRoot:c.frozenGitRoot,actualWorkingEdits:edits,publicCommitCreated:false,requiresNewReadOnlyConsumer:true};
}

// Separate RO consumer executes real tests between repair-freeze/accept-retest.
// No executeBoundRetests stub is exported by this actual RW writer module.
