import { readFileSync, readdirSync, lstatSync, realpathSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
const digestBytes=bytes=>createHash('sha256').update(bytes).digest('hex');

const check=(ok,m)=>{if(!ok)throw Error(m);};
const HEX=/^[a-f0-9]{40}$/;
const SHA=/^[a-f0-9]{64}$/;
const safe=p=>typeof p==='string'&&p&&!p.startsWith('/')&&!p.includes('\\')&&!p.includes('\0')&&p.split('/').every(s=>s&&s!=='.'&&s!=='..');

// Prepared NEW RO consumer helper. No invocation, no changed-tree fake commit,
// no write-tree/index refresh in RO metadata and no global Git overrides.
export function verifyWorkingTreeMetadata(root,metadataBytes,metadataSha256,candidate,sourceBytes,sourceSha256){
  check(['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_NAMESPACE','GIT_CONFIG_PARAMETERS','GIT_CONFIG_COUNT'].every(k=>!process.env[k]),'Global Git overrides prohibited');
  check(SHA.test(metadataSha256)&&digestBytes(metadataBytes)===metadataSha256&&SHA.test(sourceSha256)&&digestBytes(sourceBytes)===sourceSha256,'Actual metadata/source raw pins required');
  const m=JSON.parse(metadataBytes),source=JSON.parse(sourceBytes);
  check(m.representation==='base-commit-with-actual-working-index-tree'&&m.repository===candidate.repository&&m.commit===candidate.commit&&m.tree===candidate.tree&&HEX.test(m.baseTree)&&m.baseTree!==m.tree&&m.sourceManifestSha256===sourceSha256,'Explicit genuine changed-index-tree/base-commit representation required');
  check(source.repository===candidate.repository&&source.commit===candidate.commit&&source.tree===candidate.tree&&source.lockSha256===candidate.lockSha256&&source.fileCount===source.files.length,'Frozen source manifest identity/count mismatch');
  check(realpathSync(root)===root&&lstatSync(root).isDirectory()&&!lstatSync(root).isSymbolicLink(),'Exact real metadata root required');
  const paths=[];const visit=(dir,prefix='')=>{for(const e of readdirSync(dir,{withFileTypes:true})){const p=prefix?prefix+'/'+e.name:e.name,st=lstatSync(join(dir,e.name));check(!st.isSymbolicLink(),'Metadata alias prohibited');if(st.isDirectory())visit(join(dir,e.name),p);else{check(st.isFile(),'Metadata special file prohibited');paths.push(p);}}};visit(root);
  check(Array.isArray(m.files)&&m.files.length>0&&new Set(m.files.map(f=>f.path)).size===m.files.length&&JSON.stringify(paths.sort())===JSON.stringify(m.files.map(f=>f.path).sort()),'Full frozen metadata file set differs');
  for(const f of m.files){check(safe(f.path)&&!['commondir','gitdir','objects/info/alternates','config.worktree'].includes(f.path),'External/unsafe metadata path');const p=join(root,f.path),s=lstatSync(p);check(s.isFile()&&s.size===f.bytes&&SHA.test(f.sha256)&&digestBytes(readFileSync(p))===f.sha256&&Boolean(s.mode&0o111)===(f.mode==='100755'),'Metadata hash/mode/size drift: '+f.path);}
  check(paths.includes('index'),'Actual changed alternate index export required');
  const git=args=>execFileSync('git',['--no-optional-locks',`--git-dir=${root}`,'-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false',...args],{encoding:'utf8',maxBuffer:32*1024*1024,timeout:30000,env:{...process.env,GIT_NO_REPLACE_OBJECTS:'1',GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0'}});
  check(git(['rev-parse','HEAD']).trim()===m.commit&&git(['rev-parse','HEAD^{tree}']).trim()===m.baseTree&&git(['rev-parse',m.tree+'^{tree}']).trim()===m.tree,'Actual base HEAD/tree or genuine changed tree object differs');
  const tuples=text=>text.split('\0').filter(Boolean).map(entry=>{const tab=entry.indexOf('\t');check(tab>0,'Git tree/index entry delimiter');const fields=entry.slice(0,tab).split(' '),path=entry.slice(tab+1);check(fields.length===3&&safe(path)&&['100644','100755'].includes(fields[0])&&HEX.test(fields[2]==='0'?fields[1]:fields[2]),'Unsafe Git tree/index entry');return{path,mode:fields[0],gitBlob:fields[2]==='0'?fields[1]:fields[2]};});
  const tree=tuples(git(['ls-tree','-r','-z','--full-tree',m.tree]));
  const index=tuples(git(['ls-files','--stage','-z']));
  const sort=list=>list.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
  const expected=source.files.map(f=>{check(safe(f.path)&&HEX.test(f.gitBlob)&&['100644','100755'].includes(f.mode),'Source Git tuple missing');return{path:f.path,mode:f.mode,gitBlob:f.gitBlob};});
  check(new Set(expected.map(f=>f.path)).size===expected.length&&JSON.stringify(sort(tree))===JSON.stringify(sort(index))&&JSON.stringify(sort(tree))===JSON.stringify(sort(expected)),'Actual frozen tree/index/source full Git identities differ');
  const tags=git(['ls-remote','--tags',root]).trim().split(/\r?\n/).filter(Boolean).map(l=>{const [object,ref]=l.split('\t');return{ref,object};}).sort((a,b)=>a.ref.localeCompare(b.ref,'en'));
  check(Array.isArray(m.tags)&&m.tags.length>0&&JSON.stringify(tags)===JSON.stringify(m.tags),'Actual preserved full tag refs differ');
  return{commit:m.commit,tree:m.tree,baseTree:m.baseTree,representation:m.representation,metadataManifestSha256:metadataSha256,sourceManifestSha256:sourceSha256,files:m.files.length,sourceFiles:source.fileCount,tagRefs:tags.length,changedTreeIsPublicCommit:false,indexAndTreeParityVerified:true};
}
