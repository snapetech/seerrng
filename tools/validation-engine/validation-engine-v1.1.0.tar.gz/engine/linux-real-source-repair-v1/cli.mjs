import { lstat, realpath, readdir, unlink } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRepairQueue, digestBytes } from '../engine-repair-integration-v4/repair.mjs';
import { preparePlan } from '../engine-controller-priority-v2/controller.mjs';
import { planRetests } from '../engine-controller-priority-v2/retest.mjs';
import { cloneExactSource, freezeActualSource, verifySource, sameCandidate, logicalPath, rootBoundary, readPinned, recordNew, writeNew } from './filesystem.mjs';

// Prepared literal CLI; importing it does not execute. Root must review and
// authorize an explicit clone OR repair-freeze invocation in a NEW worker.
const HASH=/^[a-f0-9]{64}$/;
const check=(v,m)=>{if(!v)throw Error(m);};
export async function verifyWorker(c){
  const raw=await readPinned(c.workerInspectPath,c.workerInspectSha256),parsed=JSON.parse(raw),i=Array.isArray(parsed)?parsed[0]:parsed;
  check(i.Id===c.workerId&&i.Image===c.runtimeImageId&&i.HostConfig.NetworkMode==='none'&&i.HostConfig.ReadonlyRootfs===true&&i.HostConfig.Init===true,'Exact actual isolated worker inspect required');
  const specs=[{root:c.baselineRoot,volume:c.baselineVolume,rw:false},{root:c.workingRoot,volume:c.workingVolume,rw:true},{root:c.metadataRoot,volume:c.metadataVolume,rw:false},{root:c.evidenceRoot,volume:c.evidenceVolume,rw:true}];
  if(c.action==='repair-freeze')specs.push({root:c.frozenRoot,volume:c.frozenVolume,rw:true});
  const names=specs.map(s=>s.volume);check(new Set(names).size===names.length&&names.every(n=>typeof n==='string'&&n.length>0),'Distinct exact volume identities required');
  const expected=new Set([...specs.map(s=>s.root),c.recipesRoot,c.inputRoot]);
  const roots=[...expected];check(roots.length===specs.length+2&&roots.every(a=>roots.every(b=>a===b||!a.startsWith(b+'/'))),'Mount roots must be distinct and nonoverlapping');
  check(i.Mounts.length===expected.size&&i.Mounts.every(m=>expected.has(m.Destination)),'Undeclared config/DB/dependency/socket mounts forbidden');
  for(const s of specs)check(i.Mounts.filter(m=>m.Destination===s.root).length===1&&i.Mounts.some(m=>m.Destination===s.root&&m.Type==='volume'&&m.Name===s.volume&&m.RW===s.rw),'Exact volume mount mismatch: '+s.root);
  for(const root of [c.recipesRoot,c.inputRoot])check(i.Mounts.some(m=>m.Destination===root&&m.RW===false),'Recipes/input must be RO');
  const protectedVolumes=c.protectedVolumeNames;check(Array.isArray(protectedVolumes)&&protectedVolumes.includes(c.baselineVolume)&&protectedVolumes.includes(c.metadataVolume)&&[c.workingVolume,c.evidenceVolume,c.frozenVolume].filter(Boolean).every(v=>!protectedVolumes.includes(v)),'Explicit original/preview/config/deps protection list required');
  for(const root of expected)await rootBoundary(root);
  check(resolve(c.privateGitRoot).startsWith(c.evidenceRoot+'/')&&resolve(c.indexPath).startsWith(c.evidenceRoot+'/')&&resolve(c.frozenGitRoot).startsWith(c.evidenceRoot+'/'),'Private metadata/index/export must remain under NEW evidence volume');
  check(c.gitBinary&&c.gitBinary.startsWith('/')&&HASH.test(c.gitBinarySha256),'Reviewed genuine Git binary path/hash required');await readPinned(c.gitBinary,c.gitBinarySha256);
  // The existing source mountpoint was created empty during actual provenance
  // preparation. Ignore it only when empty, not by broad source exclusions.
  check(Array.isArray(c.baselineRootMountNames)&&c.baselineRootMountNames.every(n=>n==='node_modules'),'No automatic source exclusions beyond proved empty mountpoint');
  for(const name of c.baselineRootMountNames){const path=resolve(c.baselineRoot,name),st=await lstat(path);check(st.isDirectory()&&!st.isSymbolicLink()&&await realpath(path)===path&&(await readdir(path)).length===0,'Excluded root mountpoint must actually be empty');}
  return i;
}
async function reviewedModule(spec){
  check(spec.rootReviewed===true&&HASH.test(spec.sha256)&&HASH.test(spec.approvalSha256),'Explicit root reviewed module authority required');await readPinned(spec.path,spec.sha256);return import(pathToFileURL(spec.path).href);
}
export async function invokeReviewedAction(c){
  check(c.rootReviewed===true&&HASH.test(c.approvalSha256)&&c.userSelected==='same-files-as-last-run'&&c.authority==='dedicated-real-working-volume'&&c.allOtherWorkingVolumeWritersExcluded===true&&HASH.test(c.writerAdmissionEvidenceSha256),'Explicit selected source/sole writer authority required');
  check(['clone','repair-freeze'].includes(c.action),'Explicit supported action required; no default run');await verifyWorker(c);
  const manifestBytes=await readPinned(c.sourceManifestPath,c.sourceManifestSha256),manifest=JSON.parse(manifestBytes);
  check(sameCandidate({...manifest,lockSha256:manifest.lockSha256},c.candidate)&&manifest.fileCount===c.expectedFileCount,'Last-run actual immutable source identity required');
  const lease=resolve(c.evidenceRoot,'working-source-writer.lease');await writeNew(lease,Buffer.from(JSON.stringify({workingVolume:c.workingVolume,workerId:c.workerId,approval:c.approvalSha256})+'\n'));
  let clean=false;
  try{
    if(c.action==='clone'){
      const proof=await cloneExactSource(c,manifest);const receipt=await recordNew(c.evidenceRoot,'clone-receipt.json',proof);clean=true;return{...proof,receipt};
    }
    const cloneBytes=await readPinned(c.cloneReceiptPath,c.cloneReceiptSha256),clone=JSON.parse(cloneBytes);
    check(clone.passed===true&&clone.purpose==='actual-exact-source-working-volume-clone'&&sameCandidate(clone.candidate,c.candidate)&&clone.workingVolume===c.workingVolume&&clone.sourceVolume===c.baselineVolume,'Actual completed same working-volume clone required');
    await verifySource(c.workingRoot,manifest);await verifySource(c.baselineRoot,manifest,{allowRootMountNames:c.baselineRootMountNames});
    const snapshotBytes=await readPinned(c.baseSnapshotPath,c.baseSnapshotSha256),snapshot=JSON.parse(snapshotBytes);check(sameCandidate(snapshot.candidate,c.candidate)&&HASH.test(snapshot.executionEnvironmentSha256),'Exact last-run actual environment snapshot required');
    check(Object.keys(snapshot.sourceHashes).length===manifest.fileCount&&manifest.files.every(f=>snapshot.sourceHashes[f.path]===f.sha256),'Original snapshot/source manifest mismatch');
    const handlerModule=await reviewedModule(c.handlerModule),handlers=await handlerModule.createApprovedHandlers({manifest,candidate:c.candidate,inputRoot:c.inputRoot});
    check(Array.isArray(handlers)&&handlers.length>0,'Semantic approved real-file handler registry required; no invented fixes');
    const allowed=new Set(c.allowedWritePaths.map(logicalPath)),protectedPaths=new Set(c.protectedSourcePaths.map(logicalPath));
    for(const h of handlers)check(h.rootReviewed===true&&h.approvalSha256===c.handlerModule.approvalSha256&&h.writes.every(p=>allowed.has(logicalPath(p))&&!protectedPaths.has(p)),'Handler write ownership/approval differs');
    const failureModule=await reviewedModule(c.failureParserModule);
    const original=[];check(Array.isArray(c.failures)&&c.failures.length>0&&c.failures.length<=c.maxRequests,'Bounded actual original failures required');
    for(let index=0;index<c.failures.length;index++){
      const f=c.failures[index],bytes=await readPinned(f.path,f.sha256),failure=await failureModule.acceptActualFailure({bytes,sha256:f.sha256,snapshot});
      check(failure.actualFailure===true&&failure.assertionFailure===true&&failure.lifecycleVerified===true&&failure.sourcePreservationVerified===true&&sameCandidate(failure.candidate,c.candidate)&&typeof failure.failedUnitId==='string'&&typeof failure.runId==='string','Nonassertion, foreign, tainted or unpreserved failure cannot authorize repairs');
      await writeNew(resolve(c.evidenceRoot,'original-failure-'+index+'.json'),bytes);
      const request={candidate:c.candidate,runId:failure.runId,failedUnitId:failure.failedUnitId,failureEvidenceSha256:f.sha256,handlerId:f.handlerId,failure};original.push(request);
    }
    // Validate and preserve ALL input failures before any real source callback.
    const queue=await createRepairQueue({root:c.workingRoot,immutableRoot:c.baselineRoot,snapshot,handlers,concurrency:c.repairSlots,maxRequests:c.maxRequests});
    for(const request of original)void queue.enqueue(request);
    const repairs=await queue.drain();await recordNew(c.evidenceRoot,'actual-source-repair-results.json',{repairs,original,workingVolume:c.workingVolume});
    const edits=repairs.results.filter(r=>r.status==='applied').flatMap(r=>r.changedFiles);
    if(!repairs.ok||repairs.tainted||!edits.length)return{passed:false,reviewRequired:true,repairs,fixedCount:0,testsRun:0};
    const frozen=await freezeActualSource(c,manifest,edits);const frozenReceipt=await recordNew(c.evidenceRoot,'frozen-source-receipt.json',frozen);
    const planModule=await reviewedModule(c.affectedPlanModule),next=await planModule.buildFrozenValidationInputs({frozen,previousSnapshot:snapshot});
    const plan=preparePlan(next.plan);check(sameCandidate(plan.candidate,frozen.candidate)&&sameCandidate(next.snapshot.candidate,frozen.candidate)&&manifest.files.every(f=>next.snapshot.sourceHashes[f.path]===frozen.sourceHashes[f.path]),'Actual changed frozen candidate/hash plan required');
    const priorBytes=await readPinned(c.previousResultsPath,c.previousResultsSha256),prior=JSON.parse(priorBytes);
    const affected=planRetests(plan,{runId:c.previousRunId,snapshot,results:prior},next.snapshot);
    const broad=affected.globalReasons.length>0||affected.units.some(u=>u.reasons.some(r=>/unknown|missing|incomplete/.test(r)));
    const result={purpose:'actual-working-source-repair-and-frozen-affected-selection',workingVolume:c.workingVolume,candidate:frozen.candidate,repairs,frozenReceipt,affected,broadRevalidationRequested:broad,requiredUnitIds:broad?plan.units.map(u=>u.id):affected.retestUnitIds,fixedCount:0,actualAppliedFiles:edits,testsRun:0,acceptancePending:true,releaseGatePassed:false,readOnlySnapshotConsumerRequired:true};
    await recordNew(c.evidenceRoot,'affected-selection.json',result);clean=true;return result;
  }finally{if(clean)await unlink(lease);/* On any partial/uncertain failure retain lease/evidence for root recovery. */}
}
async function main(){
  const args=process.argv.slice(2);check(args.length===4&&args[0]==='--review'&&args[2]==='--review-sha256','Usage: node cli.mjs --review /input/review.json --review-sha256 <actualSHA256>');
  const config=JSON.parse(await readPinned(args[1],args[3]));const result=await invokeReviewedAction(config);process.stdout.write(JSON.stringify(result)+'\n');if(result.passed===false)process.exitCode=1;
}
if(process.argv[1]&&resolve(process.argv[1])===resolve(new URL(import.meta.url).pathname))main().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1;});
