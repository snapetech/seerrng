import { lstat, realpath, readdir, readFile, open, mkdir, chmod } from 'node:fs/promises';
import { resolve, relative, isAbsolute, sep } from 'node:path';
import { spawn } from 'node:child_process';
import { digestBytes } from '../engine-repair-integration-v4/repair.mjs';

const SHA=/^[a-f0-9]{64}$/;
const GIT=/^[a-f0-9]{40}$/;
const check=(ok,message)=>{if(!ok)throw Error(message);};
export const sameCandidate=(a,b)=>a&&b&&['repository','commit','tree','lockSha256'].every(k=>a[k]===b[k]);
export function logicalPath(p){
  check(typeof p==='string'&&p.length>0&&!p.includes('\\')&&!p.includes('\0')&&!isAbsolute(p),'Unsafe logical file path');
  check(p.split('/').every(s=>s&&s!=='.'&&s!=='..')&&!p.startsWith('.git/')&&p!=='.git'&&!p.startsWith('node_modules/')&&p!=='node_modules','Metadata/dependencies/ambiguous paths forbidden');return p;
}
async function regular(root,p){
  const path=resolve(root,logicalPath(p)),rel=relative(root,path);
  check(rel&&!isAbsolute(rel)&&rel!=='..'&&!rel.startsWith('..'+sep),'Path escaped source boundary');
  const stat=await lstat(path);check(stat.isFile()&&!stat.isSymbolicLink()&&await realpath(path)===path,'Regular unaliased file required: '+p);return{path,stat};
}
export async function rootBoundary(root){check(process.platform==='linux'&&isAbsolute(root)&&await realpath(root)===root,'Exact real Linux mount root required');return root;}
export async function readPinned(path,sha){const bytes=await readFile(path);check(SHA.test(sha)&&digestBytes(bytes)===sha,'Input receipt/recipe hash mismatch: '+path);return bytes;}
export async function writeNew(path,bytes,mode=0o600){const file=await open(path,'wx',mode);try{await file.writeFile(bytes);await file.sync();}finally{await file.close();}await chmod(path,mode);}
export async function recordNew(root,name,value){check(/^[A-Za-z0-9._-]+\.json$/.test(name),'Bounded receipt name required');const bytes=Buffer.from(JSON.stringify(value,null,2)+'\n');await writeNew(resolve(root,name),bytes);return{path:resolve(root,name),sha256:digestBytes(bytes)};}

// .git/node_modules are ignored ONLY as separately verified RO metadata/deps
// mount roots. No config/database/generated-output pattern exclusions exist.
export async function verifySource(root,manifest,{allowRootMountNames=[]}={}){
  await rootBoundary(root);check(manifest.schema===1&&GIT.test(manifest.commit)&&GIT.test(manifest.tree)&&SHA.test(manifest.lockSha256)&&manifest.fileCount===manifest.files.length,'Exact committed source manifest required');
  check(allowRootMountNames.every(n=>['.git','node_modules'].includes(n)),'Unknown walker exclusion');
  const paths=manifest.files.map(f=>logicalPath(f.path));check(new Set(paths).size===paths.length,'Duplicate source identity');
  const actual=[];
  const walk=async(dir,prefix='')=>{for(const e of await readdir(dir,{withFileTypes:true})){
    if(!prefix&&allowRootMountNames.includes(e.name))continue;
    const p=prefix?prefix+'/'+e.name:e.name;check(!e.isSymbolicLink(),'Source alias forbidden: '+p);
    if(e.isDirectory())await walk(resolve(dir,e.name),p);else{check(e.isFile(),'Source special file forbidden: '+p);actual.push(p);}
  }};await walk(root);check(JSON.stringify(actual.sort())===JSON.stringify([...paths].sort()),'Complete source file set differs');
  const hashes={};
  for(const f of manifest.files){check(SHA.test(f.sha256)&&['100644','100755'].includes(f.mode)&&Number.isSafeInteger(f.bytes)&&f.bytes>=0,'Manifest hash/mode/size invalid');const{path,stat}=await regular(root,f.path);const bytes=await readFile(path);check(bytes.length===f.bytes&&digestBytes(bytes)===f.sha256&&Boolean(stat.mode&0o111)===(f.mode==='100755'),'Source bytes or executable mode differ: '+f.path);hashes[f.path]=f.sha256;}
  return{fileCount:paths.length,sourceHashes:hashes,manifestObjectSha256:digestBytes(Buffer.from(JSON.stringify(manifest)))};
}
async function empty(root){await rootBoundary(root);check((await readdir(root)).length===0,'NEW empty destination required: '+root);}
async function copyManifestFiles(from,to,files){for(const f of files){const input=await regular(from,f.path);const bytes=await readFile(input.path);check(digestBytes(bytes)===f.sha256,'Copy input changed: '+f.path);const dest=resolve(to,logicalPath(f.path));await mkdir(resolve(dest,'..'),{recursive:true,mode:0o755});await writeNew(dest,bytes,f.mode==='100755'?0o755:0o644);}}

// Executed only by a separately approved CLI invocation. No shell or Git
// hooks/commits/fetch/builds; alternate index and object writes stay PRIVATE.
async function git(config,args,input){
  const env={...process.env,GIT_DIR:config.privateGitRoot,GIT_WORK_TREE:config.workingRoot,GIT_INDEX_FILE:config.indexPath,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_NO_REPLACE_OBJECTS:'1',GIT_TERMINAL_PROMPT:'0'};
  delete env.GIT_ALTERNATE_OBJECT_DIRECTORIES;
  return await new Promise((accept,reject)=>{const child=spawn(config.gitBinary??'/usr/bin/git',['-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false',...args],{env,stdio:['pipe','pipe','pipe']});const stdout=[],stderr=[];let count=0;child.stdout.on('data',b=>{count+=b.length;if(count>4*1024*1024)child.kill('SIGTERM');stdout.push(b);});child.stderr.on('data',b=>stderr.push(b));child.once('error',reject);child.once('close',(code,signal)=>{const out=Buffer.concat(stdout);if(code!==0||signal||count>4*1024*1024)reject(Error('Private Git operation failed: '+args[0]+' code='+code+' signal='+signal+' '+Buffer.concat(stderr).toString().slice(0,1500)));else accept(out.toString().trim());});child.stdin.end(input);});
}
async function copyMetadata(config){
  const metaBytes=await readPinned(config.metadataManifestPath,config.metadataManifestSha256),meta=JSON.parse(metaBytes);
  check(Array.isArray(meta.files)&&meta.files.length>0&&meta.repository===config.candidate.repository&&meta.commit===config.candidate.commit&&meta.tree===config.candidate.tree&&meta.sourceManifestSha256===config.sourceManifestSha256,'Exact root-reviewed genuine Git metadata inventory required');
  const files=meta.files.map(f=>({...f,path:logicalPath(f.path)}));check(new Set(files.map(f=>f.path)).size===files.length&&!files.some(f=>['commondir','gitdir','objects/info/alternates','config.worktree','index'].includes(f.path)),'Duplicate/aliased external metadata or existing index forbidden');
  await empty(config.privateGitRoot);const actual=[];
  const walk=async(d,prefix='')=>{for(const e of await readdir(d,{withFileTypes:true})){const p=prefix?prefix+'/'+e.name:e.name;check(!e.isSymbolicLink(),'Metadata symlinks forbidden');if(e.isDirectory())await walk(resolve(d,e.name),p);else{check(e.isFile(),'Metadata special file forbidden');actual.push(p);}}};await walk(config.metadataRoot);
  check(JSON.stringify(actual.sort())===JSON.stringify(files.map(f=>f.path).sort()),'Actual metadata file set differs');
  await copyManifestFiles(config.metadataRoot,config.privateGitRoot,files);
  for(const f of files){const bytes=await readFile(resolve(config.privateGitRoot,f.path));check(digestBytes(bytes)===f.sha256,'Private metadata readback failed');}
  check(await git(config,['rev-parse',config.candidate.commit+'^{commit}'])===config.candidate.commit&&await git(config,['rev-parse',config.candidate.commit+'^{tree}'])===config.candidate.tree,'Genuine base Git object identity required');
  await git(config,['read-tree',config.candidate.commit]);check(await git(config,['write-tree'])===config.candidate.tree,'Private alternate base index differs');
}
export async function cloneExactSource(config,manifest){
  const before=await verifySource(config.baselineRoot,manifest,{allowRootMountNames:config.baselineRootMountNames??[]});
  try{await lstat(config.indexPath);throw Error('Alternate index path already exists');}catch(e){if(e.code!=='ENOENT')throw e;}
  await empty(config.workingRoot);await mkdir(config.privateGitRoot,{mode:0o700});await copyManifestFiles(config.baselineRoot,config.workingRoot,manifest.files);
  const copied=await verifySource(config.workingRoot,manifest);await copyMetadata(config);
  const after=await verifySource(config.baselineRoot,manifest,{allowRootMountNames:config.baselineRootMountNames??[]});
  check(JSON.stringify(before.sourceHashes)===JSON.stringify(after.sourceHashes),'Protected original source changed during clone');
  return{purpose:'actual-exact-source-working-volume-clone',passed:true,candidate:config.candidate,sourceVolume:config.baselineVolume,workingVolume:config.workingVolume,fileCount:copied.fileCount,sourceBefore:before,sourceAfter:after,working:copied,privateGitRoot:config.privateGitRoot,indexPath:config.indexPath,testsRun:0,commitsCreated:0};
}
export async function freezeActualSource(config,manifest,acceptedEdits){
  check(Array.isArray(acceptedEdits)&&acceptedEdits.length>0,'Actual applied queue edits required');
  const edits=new Map();for(const e of acceptedEdits){logicalPath(e.path);check(!edits.has(e.path)&&SHA.test(e.afterSha256)&&manifest.files.some(f=>f.path===e.path&&f.sha256===e.beforeSha256),'Duplicate or invalid applied replacement');edits.set(e.path,e);}
  const nextFiles=[];
  for(const f of manifest.files){const{path,stat}=await regular(config.workingRoot,f.path);const bytes=await readFile(path);const sha=digestBytes(bytes);check(sha===(edits.get(f.path)?.afterSha256??f.sha256)&&Boolean(stat.mode&0o111)===(f.mode==='100755'),'Unowned source mutation or mode drift: '+f.path);nextFiles.push({...f,bytes:bytes.length,sha256:sha});}
  const draft={...manifest,files:nextFiles};await verifySource(config.workingRoot,draft);await verifySource(config.baselineRoot,manifest,{allowRootMountNames:config.baselineRootMountNames??[]});
  check(await git(config,['rev-parse',config.candidate.commit+'^{tree}'])===config.candidate.tree&&await git(config,['write-tree'])===config.candidate.tree,'Private base metadata/index drift before freeze');
  for(const f of nextFiles.filter(f=>edits.has(f.path))){const bytes=await readFile(resolve(config.workingRoot,f.path));check(digestBytes(bytes)===f.sha256,'Replacement changed during Git hashing');const blob=await git(config,['hash-object','-w','--stdin'],bytes);check(GIT.test(blob),'Actual Git blob identity missing');await git(config,['update-index','--add','--cacheinfo',f.mode+','+blob+','+f.path]);f.gitBlob=blob;}
  const tree=await git(config,['write-tree']);check(GIT.test(tree)&&tree!==config.candidate.tree,'Actual changed Git tree required; commit remains genuine base');
  const candidate={...config.candidate,tree};const frozen={...draft,tree,files:nextFiles};
  await empty(config.frozenRoot);await copyManifestFiles(config.workingRoot,config.frozenRoot,nextFiles);const frozenProof=await verifySource(config.frozenRoot,frozen);await verifySource(config.workingRoot,frozen);const originalProof=await verifySource(config.baselineRoot,manifest,{allowRootMountNames:config.baselineRootMountNames??[]});
  await mkdir(config.frozenGitRoot,{mode:0o700});await empty(config.frozenGitRoot);const metadataFiles=[];
  const walkGit=async(d,prefix='')=>{for(const e of await readdir(d,{withFileTypes:true})){const p=prefix?prefix+'/'+e.name:e.name;check(!e.isSymbolicLink(),'Private Git metadata alias');if(e.isDirectory())await walkGit(resolve(d,e.name),p);else{check(e.isFile(),'Private Git metadata special file');const st=await lstat(resolve(d,e.name)),bytes=await readFile(resolve(d,e.name));metadataFiles.push({path:p,mode:st.mode&0o111?'100755':'100644',bytes:bytes.length,sha256:digestBytes(bytes)});}}};await walkGit(config.privateGitRoot);
  check(!metadataFiles.some(f=>f.path==='index'),'Original metadata index unexpectedly conflicts with explicit alternate index');
  await copyManifestFiles(config.privateGitRoot,config.frozenGitRoot,metadataFiles);
  const indexBytes=await readFile(config.indexPath);await writeNew(resolve(config.frozenGitRoot,'index'),indexBytes);metadataFiles.push({path:'index',mode:'100644',bytes:indexBytes.length,sha256:digestBytes(indexBytes)});
  check(await git({...config,privateGitRoot:config.frozenGitRoot,indexPath:resolve(config.frozenGitRoot,'index')},['write-tree'])===tree,'Frozen genuine Git metadata/index tree differs');
  return{purpose:'actual-source-repair-frozen-tree-export',passed:true,candidate,baseCandidate:config.candidate,manifest:frozen,sourceHashes:frozenProof.sourceHashes,sourceVolume:config.workingVolume,frozenVolume:config.frozenVolume,frozenRoot:config.frozenRoot,fileCount:frozenProof.fileCount,privateGitRoot:config.privateGitRoot,indexPath:config.indexPath,frozenGitRoot:config.frozenGitRoot,frozenMetadataFiles:metadataFiles,originalProof,actualGitTreeVerified:true,publicCommitCreated:false,testsRun:0,readOnlyConsumerMountRequired:true};
}
