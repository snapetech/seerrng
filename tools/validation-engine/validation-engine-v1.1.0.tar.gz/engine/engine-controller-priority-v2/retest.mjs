import { preparePlan, resourceKey } from './controller.mjs';
import { effectiveDependencies } from './priority.mjs';

const HASH64 = /^[a-f0-9]{64}$/;
const identityKeys = ['repository', 'commit', 'tree', 'lockSha256'];
const sameIdentity = (a, b) => Boolean(a && b && identityKeys.every((key) => a[key] === b[key]));
const object = (value) => value && typeof value === 'object' && !Array.isArray(value);
const canonicalMap = (value, plan, label, hashes = false) => {
  if (!object(value)) throw new Error(`${label} must be an explicit object`);
  const result = new Map();
  for (const [key, item] of Object.entries(value)) {
    const path = resourceKey(key, plan.caseSensitive);
    if (result.has(path)) throw new Error(`aliased ${label}`);
    if (hashes && !HASH64.test(item)) throw new Error(`invalid ${label} digest`);
    if (!hashes && (!Array.isArray(item) || item.some((entry) => typeof entry !== 'string'))) throw new Error(`invalid ${label} dependencies`);
    result.set(path, hashes ? item : [...new Set(item.map((entry) => resourceKey(entry, plan.caseSensitive)))].sort());
  }
  return result;
};

// Hashes are supplied verified snapshot evidence; this pure planner does not
// read live files, infer imports, perform repairs or certify caller completeness.
export function planRetests(inputPlan, previous, nextSnapshot) {
  const plan = preparePlan(inputPlan);
  if (!object(previous) || typeof previous.runId !== 'string' || previous.runId === plan.runId
      || !object(previous.snapshot) || !object(previous.results)) throw new Error('fresh run and explicit previous snapshot/results required');
  if (!sameIdentity(nextSnapshot?.candidate, plan.candidate)) throw new Error('new snapshot identity does not match plan');
  // Reuse the existing exact-identity validation, not an abbreviated SHA check.
  preparePlan({ ...inputPlan, candidate: previous.snapshot.candidate });
  if (previous.snapshot.candidate.repository !== plan.candidate.repository) throw new Error('cross-repository retained evidence forbidden');
  const oldHashes = canonicalMap(previous.snapshot.sourceHashes, plan, 'old sourceHashes', true);
  const newHashes = canonicalMap(nextSnapshot.sourceHashes, plan, 'new sourceHashes', true);
  const oldGraph = canonicalMap(previous.snapshot.dependencies ?? {}, plan, 'old dependency graph');
  const newGraph = canonicalMap(nextSnapshot.dependencies ?? {}, plan, 'new dependency graph');
  const changed = [...new Set([...oldHashes.keys(), ...newHashes.keys()])].filter((path) => oldHashes.get(path) !== newHashes.get(path)).sort();
  if (changed.length && previous.snapshot.candidate.commit === plan.candidate.commit
      && previous.snapshot.candidate.tree === plan.candidate.tree) throw new Error('source edit requires a new candidate commit/tree identity');
  const closure = (paths, graph, hashes) => {
    const reached = new Set(); let complete = true;
    const visit = (path) => {
      if (reached.has(path)) return;
      reached.add(path);
      if (!hashes.has(path) || !graph.has(path)) { complete = false; return; }
      graph.get(path).forEach(visit);
    };
    paths.forEach(visit);
    return { paths: [...reached].sort(), complete };
  };
  const units = new Map();
  const knownInputs = new Set();
  for (const unit of plan.units) {
    const declared = unit.validationInputs;
    const reasons = [];
    let paths = [];
    if (!object(declared) || declared.complete !== true || !Array.isArray(declared.paths)
        || declared.paths.some((path) => typeof path !== 'string') || !HASH64.test(declared.contractSha256)) {
      reasons.push('unknown or incomplete validation input/command contract');
    } else {
      paths = declared.paths.map((path) => resourceKey(path, plan.caseSensitive));
      if (new Set(paths).size !== paths.length) throw new Error('duplicate declared validation inputs');
      if ([...unit.reads, ...unit.files].some((path) => !paths.includes(path))) reasons.push('declared input contract omits a read/test file');
    }
    const oldClosure = closure(paths, oldGraph, oldHashes);
    const newClosure = closure(paths, newGraph, newHashes);
    newClosure.paths.forEach((path) => knownInputs.add(path));
    oldClosure.paths.forEach((path) => knownInputs.add(path));
    if (!oldClosure.complete || !newClosure.complete) reasons.push('missing source hash or transitive input declaration');
    const old = previous.results[unit.id];
    if (!object(old) || old.status !== 'passed' || !HASH64.test(old.evidenceSha256)
        || !sameIdentity(old.candidate, previous.snapshot.candidate) || old.runId !== previous.runId) reasons.push('no identity-bound successful previous receipt');
    if (!HASH64.test(old?.executionEnvironmentSha256) || old.executionEnvironmentSha256 !== previous.snapshot.executionEnvironmentSha256) reasons.push('previous receipt environment identity missing or mismatched');
    if (old?.contractSha256 !== declared?.contractSha256) reasons.push('check command/setup contract changed or unknown');
    const allPaths = [...new Set([...oldClosure.paths, ...newClosure.paths])].sort();
    if (allPaths.some((path) => oldHashes.get(path) !== newHashes.get(path))) reasons.push('declared source or transitive dependency content changed');
    if (JSON.stringify(oldClosure.paths) !== JSON.stringify(newClosure.paths)
        || allPaths.some((path) => JSON.stringify(oldGraph.get(path)) !== JSON.stringify(newGraph.get(path)))) reasons.push('declared dependency topology changed');
    if (!object(old?.inputHashes) || oldClosure.paths.some((path) => old.inputHashes[path] !== oldHashes.get(path))
        || Object.keys(old?.inputHashes ?? {}).some((path) => !oldClosure.paths.includes(path))) reasons.push('previous receipt input hashes do not match exact closure');
    units.set(unit.id, { id: unit.id, action: reasons.length ? 'retest' : 'retain-green', reasons: [...new Set(reasons)],
      transitiveInputPaths: newClosure.paths, previousEvidenceSha256: reasons.length ? null : old.evidenceSha256,
      retainedFromCandidate: reasons.length ? null : previous.snapshot.candidate,
      retainedEvidenceIsExecutionOnNewCandidate: false });
  }
  const globalReasons = [];
  if (previous.snapshot.candidate.lockSha256 !== plan.candidate.lockSha256) globalReasons.push('dependency lockfile identity changed');
  if (!HASH64.test(previous.snapshot.executionEnvironmentSha256) || !HASH64.test(nextSnapshot.executionEnvironmentSha256)
      || !HASH64.test(plan.executionEnvironmentSha256)) globalReasons.push('execution environment identity missing');
  else if (previous.snapshot.executionEnvironmentSha256 !== nextSnapshot.executionEnvironmentSha256
      || nextSnapshot.executionEnvironmentSha256 !== plan.executionEnvironmentSha256) globalReasons.push('execution environment identity changed or mismatched');
  if (previous.snapshot.impactComplete !== true || nextSnapshot.impactComplete !== true) globalReasons.push('global source impact classification unknown');
  const unmapped = changed.filter((path) => !knownInputs.has(path));
  if (unmapped.length) globalReasons.push('changed source outside declared validation closures');
  if (globalReasons.length) for (const entry of units.values()) {
    entry.action = 'retest'; entry.previousEvidenceSha256 = null; entry.retainedFromCandidate = null;
    entry.reasons.push(...globalReasons);
  }
  const dependencies = effectiveDependencies(plan);
  let modified;
  do {
    modified = false;
    for (const [id, parents] of dependencies) {
      const entry = units.get(id);
      if (entry.action === 'retain-green' && parents.some((parent) => units.get(parent).action === 'retest')) {
        entry.action = 'retest'; entry.previousEvidenceSha256 = null; entry.retainedFromCandidate = null;
        entry.reasons.push('declared upstream validation dependency invalidated'); modified = true;
      }
    }
  } while (modified);
  return {
    schemaVersion: 2, status: 'proposal-not-executed', runId: plan.runId, candidate: plan.candidate,
    previousRunId: previous.runId, sourceChangedPaths: changed, unknownChangedPaths: unmapped,
    globalReasons, units: [...units.values()],
    retestUnitIds: [...units.values()].filter((entry) => entry.action === 'retest').map((entry) => entry.id),
    retainedUnitIds: [...units.values()].filter((entry) => entry.action === 'retain-green').map((entry) => entry.id),
    limits: ['Caller proves hash snapshots and complete contracts; this planner cannot infer authoritative impact.',
      'Retained-green evidence is reuse, never a new executed pass or release artifact.',
      'New candidate identity required after source edits; no app, assertion or queued patch modification.',
      'No automatic adapter execution or waiver of final canonical/required release gates.'],
  };
}
