import { readFile, lstat, realpath, mkdir, open } from 'node:fs/promises';
import { resolve, dirname, relative, isAbsolute } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createWorkingRepairSession, acceptFrozenRetest } from './session.mjs';
import { digestBytes } from '../engine-repair-integration-v4/repair.mjs';

const SHA = /^[a-f0-9]{64}$/;
const check = (ok, message) => { if (!ok) throw Error(message); };
const within = (root, path) => { const r = relative(root, path); return r !== '' && !isAbsolute(r) && r !== '..' && !r.startsWith('../') && !r.startsWith('..\\'); };

// Explicit filesystem proposal provider. A human or external coding agent
// supplies exact replacement BYTES; this engine does not invent arbitrary fixes.
// All descriptors are pinned in the reviewed invocation packet, never polled.
async function boundBytes(root, descriptor, maximum = 16 * 1024 ** 2) {
  check(descriptor && typeof descriptor.path === 'string' && SHA.test(descriptor.sha256), 'Exact artifact path/hash required');
  const path = resolve(root, descriptor.path);
  check(within(root, path) && await realpath(path) === path, 'Artifact escaped packet root or uses aliases');
  const stat = await lstat(path);
  check(stat.isFile() && !stat.isSymbolicLink() && stat.size <= maximum, 'Bounded regular artifact required');
  const bytes = await readFile(path);
  check(digestBytes(bytes) === descriptor.sha256, 'Artifact bytes changed since review'); return bytes;
}
const boundJson = async (root, descriptor) => JSON.parse(await boundBytes(root, descriptor));
const save = async (path, value) => {
  const bytes = Buffer.from(`${JSON.stringify(value, null, 2)}\n`);
  const handle = await open(path, 'wx', 0o600);
  try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
  return { path, sha256: digestBytes(bytes), bytes: bytes.length };
};

async function mapping(root, descriptor) {
  const input = await boundJson(root, descriptor);
  const reportBytes = await boundBytes(root, input.report, 16 * 1024 ** 2);
  const sourcePreservationProof = await boundJson(root, input.sourcePreservationProof);
  check(sourcePreservationProof.evidenceSha256 === input.sourcePreservationSha256, 'Source proof envelope differs');
  return { ...input, reportBytes, sourcePreservationProof,
    caseLedgerBytes: input.caseLedger ? await boundBytes(root, input.caseLedger) : null,
    caseLedgerSha256: input.caseLedger?.sha256 ?? null };
}

export async function runRepairPacket(packetPath, packetSha256) {
  check(SHA.test(packetSha256), 'Reviewed invocation packet SHA required');
  const absolute = resolve(packetPath); check(await realpath(absolute) === absolute, 'Invocation packet aliases forbidden');
  const packetBytes = await readFile(absolute); check(packetBytes.length <= 1024 ** 2 && digestBytes(packetBytes) === packetSha256, 'Reviewed packet changed');
  const packet = JSON.parse(packetBytes); const packetRoot = await realpath(dirname(absolute));
  check(packet.schema === 5 && packet.rootReviewed === true && SHA.test(packet.approvalSha256)
    && ['capture', 'repair-cycle', 'repair-freeze', 'accept-retest'].includes(packet.operation), 'Explicit reviewed capture/repair operation required');
  if (packet.operation === 'accept-retest') {
    check(packet.retestAuthority?.rootApprovedExecution === true && SHA.test(packet.retestAuthority.executionApprovalSha256), 'Actual retest acceptance approval required');
    const boundary = await boundJson(packetRoot, packet.boundary); const actual = await boundJson(packetRoot, packet.actualRetest);
    check(actual.repairBoundarySha256 === packet.boundary.sha256, 'Actual consumer result belongs to a different frozen repair boundary');
    const parent = await realpath(resolve(packet.roots.journalParent));
    check(typeof packet.journalName === 'string' && /^[A-Za-z0-9._-]{1,96}$/.test(packet.journalName), 'Fresh bounded acceptance journal required');
    const destination = resolve(parent, packet.journalName); check(within(parent, destination), 'Acceptance journal escaped');
    await mkdir(destination, { mode: 0o700 });
    let result;
    try { result = acceptFrozenRetest(boundary, actual); }
    catch (error) { result = { passed: false, error: error.message, writerReplayAllowed: false, releaseGatePassed: false }; }
    const saved = await save(resolve(destination, 'retest-acceptance.json'), { schema: 5, packetSha256,
      boundarySha256: packet.boundary.sha256, actualRetestSha256: packet.actualRetest.sha256, result,
      completedAt: new Date().toISOString(), actualWorkingWrites: 0, releaseGatePassed: false });
    return { ...saved, status: result.passed ? 'repair-cycle-passed' : 'retest-failed-or-pending', exitCode: result.passed ? 0 : 1 };
  }
  const plan = await boundJson(packetRoot, packet.plan); const snapshot = await boundJson(packetRoot, packet.snapshot);
  const authority = await boundJson(packetRoot, packet.authority);
  // Host/module review is external human/Codex authority, not manufactured by
  // a JSON flag. Its exact entry bytes and the entire transitive recipe packet
  // must be approved/frozen by the caller before invoking this CLI.
  let host = null;
  let hostRecipeFiles = [];
  if (packet.host) {
    await boundBytes(packetRoot, packet.host);
    check(packet.host.rootReviewed === true && SHA.test(packet.host.recipeManifestSha256)
      && packet.host.recipeManifest?.sha256 === packet.host.recipeManifestSha256, 'Reviewed host recipe closure required');
    const closure = await boundJson(packetRoot, packet.host.recipeManifest);
    check(Array.isArray(closure.files) && closure.files.length > 0 && closure.files.length <= 256
      && new Set(closure.files.map((entry) => entry.path)).size === closure.files.length
      && closure.files.some((entry) => entry.path === packet.host.path && entry.sha256 === packet.host.sha256), 'Exact bounded unique host recipe closure required');
    hostRecipeFiles = closure.files;
    for (const entry of hostRecipeFiles) await boundBytes(packetRoot, entry);
    host = await import(pathToFileURL(resolve(packetRoot, packet.host.path)).href);
  }
  const roots = packet.roots;
  check(roots && ['working', 'immutable', 'journalParent'].every((key) => typeof roots[key] === 'string'), 'Portable explicit roots required');
  const journalParent = await realpath(resolve(roots.journalParent));
  const journalName = packet.journalName;
  check(typeof journalName === 'string' && /^[A-Za-z0-9._-]{1,96}$/.test(journalName), 'Fresh bounded journal name required');
  const journalRoot = resolve(journalParent, journalName);
  check(within(journalParent, journalRoot), 'Journal destination escaped');
  // No recursive mkdir/no overwrite: prior evidence is never resumed blindly.
  await mkdir(journalRoot, { mode: 0o700 });
  const providers = [];
  for (const provider of packet.providers ?? []) {
    check(provider.rootReviewed === true && SHA.test(provider.approvalSha256), 'Actual reviewed external provider required');
    providers.push({ id: provider.id, kind: provider.kind, rootReviewed: true, approvalSha256: provider.approvalSha256,
      propose: async ({ ticket }) => {
        const selected = provider.proposalsByUnit?.[ticket.unitId];
        if (!selected) return { status: 'review-required', reason: 'External Codex/manual provider has not supplied replacement bytes' };
        const proposal = await boundJson(packetRoot, selected);
        check(proposal.failureReceiptSha256 === ticket.originalRawEvidence.receipt.sha256
          && proposal.failureReportSha256 === ticket.originalRawEvidence.report?.sha256
          && proposal.sourceIdentity === ticket.sourceIdentity, 'Proposal belongs to another source/failure');
        check(Array.isArray(proposal.edits), 'Explicit replacement list required');
        const edits = [];
        for (const edit of proposal.edits) edits.push({ ...edit, bytes: await boundBytes(packetRoot, edit.replacement) });
        return { ...proposal, edits };
      } });
  }
  let session = null; let final = null;
  try {
    session = await createWorkingRepairSession({ plan, snapshot, authority, workingRoot: roots.working,
      immutableRoot: roots.immutable, evidenceRoot: journalRoot, providers, repairSlots: packet.repairSlots ?? 4 });
    const tickets = [];
    for (const entry of packet.nativeFailures ?? []) {
      const mapped = await mapping(packetRoot, entry.mapping);
      const ticket = await session.ingestNative(mapped, { receiptBytes: await boundBytes(packetRoot, entry.receipt), intendedWrites: entry.intendedWrites ?? [] });
      tickets.push(ticket);
    }
    if (packet.canonicalFailure) {
      const entry = packet.canonicalFailure; const mapped = await mapping(packetRoot, entry.mapping);
      const result = await session.ingestCanonical(mapped, { receiptBytes: await boundBytes(packetRoot, entry.receipt), intendedWritesByFile: entry.intendedWritesByFile ?? {} });
      tickets.push(...result.tickets);
    }
    const initial = await boundJson(packetRoot, packet.initialResults);
    session.bindInitialResults(initial);
    check(tickets.length > 0, 'Repair invocation needs an actual unresolved failure; no empty-success cycle');
    if (packet.operation === 'capture') {
      final = { status: 'pending-external-repair', actualWorkingReplacements: 0, state: session.state(), releaseGatePassed: false };
    } else {
      await Promise.all(tickets.filter((ticket) => ticket.confirmedAssertionFailure)
        .map((ticket) => session.requestProposal(ticket.id, packet.providerByUnit?.[ticket.unitId])));
      const approved = [];
      for (const ticket of session.state().tickets) {
        const review = packet.patchApprovalByUnit?.[ticket.unitId];
        if (ticket.state !== 'waiting-exact-patch-approval' || !review) continue;
        await session.approveProposal(ticket.id, await boundJson(packetRoot, review)); approved.push(ticket.id);
      }
      if (!approved.length) final = { status: 'pending-external-repair-or-exact-review', actualWorkingReplacements: 0, state: session.state(), releaseGatePassed: false };
      else {
        const required = packet.operation === 'repair-freeze' ? ['verifyWorkingAuthority', 'freezeCandidate'] : ['verifyWorkingAuthority', 'freezeCandidate', 'executeBoundRetests'];
        check(host && required.every((key) => typeof host[key] === 'function'), 'Concrete reviewed authority/freeze/retest host required');
        check(packet.retestAuthority?.rootApprovedExecution === true && SHA.test(packet.retestAuthority.executionApprovalSha256), 'Actual affected-retest approval required before modifying source');
        const context = Object.freeze({ hostConfiguration: packet.host.configuration ?? {}, packetSha256,
          recipeManifestSha256: packet.host.recipeManifestSha256, journalRoot });
        const wave = await session.applyApprovedWave(approved, { verifyWorkingAuthority: (request) => host.verifyWorkingAuthority(request, context) });
        if (!wave.ok || wave.tainted) final = { status: 'repair-failed-or-partial', wave, state: session.state(), releaseGatePassed: false };
        else {
          const queued = await session.freezeAndQueueRetests({ freezeCandidate: (request) => host.freezeCandidate(request, context) });
          if (packet.operation === 'repair-freeze') {
            const boundary = await save(resolve(journalRoot, 'frozen-repair-boundary.json'), session.exportFrozenBoundary());
            final = { status: 'working-files-changed-awaiting-separate-RO-retest', wave, queued, boundary,
              state: session.state(), actualTestsExecuted: 0, releaseGatePassed: false,
              nextStep: 'Root-owned separate source/deps/metadata-RO consumer must execute exact boundary selection; accept-retest validates its actual result without restoring writer state' };
          } else {
            const retest = await session.executeQueuedRetests({ ...packet.retestAuthority,
              executeBoundRetests: (request) => host.executeBoundRetests(request, context) });
            final = { status: retest.passed ? 'repair-cycle-passed' : 'retest-failed-or-pending', wave, queued, retest,
              state: session.state(), releaseGatePassed: false,
              nextCycle: retest.passed ? null : 'Requires fresh actual failure receipts/new immutable candidate/new reviewed packet; never replay this wave' };
          }
        }
      }
    }
  } catch (error) { final = { status: 'failed', error: error.message, state: session?.state() ?? null, releaseGatePassed: false }; }
  try { for (const entry of hostRecipeFiles) await boundBytes(packetRoot, entry); }
  catch (error) { final = { status: 'failed', error: `Host recipe changed during operation: ${error.message}`, previousResult: final, releaseGatePassed: false }; }
  const receipt = await save(resolve(journalRoot, 'invocation-result.json'), { schema: 5, packetSha256, final,
    completedAt: new Date().toISOString(), sourceEditsAreOnlyActualQueueReadbacks: true, releaseGatePassed: false });
  return { ...receipt, status: final.status, exitCode: final.status === 'repair-cycle-passed' ? 0 : final.status === 'failed' || final.status === 'repair-failed-or-partial' ? 1 : 2 };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    check(process.argv.length === 4, 'Usage: node cli.mjs reviewed-packet.json EXACT_PACKET_SHA256');
    const receipt = await runRepairPacket(process.argv[2], process.argv[3]);
    process.stdout.write(`${JSON.stringify(receipt)}\n`); process.exitCode = receipt.exitCode;
  } catch (error) { process.stderr.write(`${error.message}\n`); process.exitCode = 1; }
}
