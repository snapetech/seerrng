import { open, realpath } from 'node:fs/promises';
import { resolve, join, relative, isAbsolute } from 'node:path';
import { createRepairQueue, digestBytes } from '../engine-repair-integration-v4/repair.mjs';
import { mapCanonicalReport, logicalCanonicalPlan } from '../engine-repair-integration-v4/canonical-host-bridge.mjs';
import { mapNativeReport } from '../engine-native-repair-bridge-v2/native-host-bridge.mjs';
import { preparePlan, resourceKey } from '../engine-controller-priority-v2/controller.mjs';
import { planRetests } from '../engine-controller-priority-v2/retest.mjs';

const SHA = /^[a-f0-9]{64}$/;
const check = (ok, message) => { if (!ok) throw new Error(message); };
const same = (a, b) => Boolean(a && b && ['repository', 'commit', 'tree', 'lockSha256'].every((key) => a[key] === b[key]));
const encoded = (bytes) => ({ sha256: digestBytes(bytes), bytes: bytes.length, base64: bytes.toString('base64') });
const outside = (parent, child) => { const path = relative(parent, child); return path !== '' && (isAbsolute(path) || path === '..' || path.startsWith('../') || path.startsWith('..\\')); };
const sourceProof = (proof, plan, snapshot) => SHA.test(proof?.evidenceSha256)
  && same(proof?.receipt?.candidate, plan.candidate) && proof.receipt.postInputHashesVerified === true
  && proof.receipt.executionEnvironmentSha256 === plan.executionEnvironmentSha256
  && proof.receipt.sourceManifestSha256 === snapshot.sourceManifestSha256
  && proof.receipt.fileCount === Object.keys(snapshot.sourceHashes).length;
const keys = (paths, sensitive) => {
  check(Array.isArray(paths), 'Explicit source paths required');
  const result = paths.map((path) => resourceKey(path, sensitive));
  check(new Set(result).size === result.length, 'Duplicate/aliased file scope'); return result;
};

// Read-only acceptance after the actual separate RO test consumer. This never
// restores a writer queue or replays replacements from a saved session.
export function acceptFrozenRetest(boundary, actual) {
  check(boundary?.schema === 5 && boundary.writerReplayAllowed === false && boundary.next && boundary.selection,
    'Exact completed freeze boundary required');
  const plan = preparePlan(boundary.next.plan); const snapshot = boundary.next.snapshot; const selection = boundary.selection;
  check(same(snapshot.candidate, plan.candidate) && snapshot.executionEnvironmentSha256 === plan.executionEnvironmentSha256
    && same(selection.candidate, plan.candidate) && selection.runId === plan.runId
    && SHA.test(boundary.next.freezeReceiptSha256) && boundary.next.fullWorkingManifestVerified === true,
    'Bound freeze/source/environment/selection identity required');
  check(actual?.runId === plan.runId && same(actual.candidate, plan.candidate)
    && SHA.test(actual.evidenceSha256) && Array.isArray(actual.results), 'Actual identity-bound retest evidence required');
  const ids = actual.results.map((record) => record.id);
  check(new Set(ids).size === ids.length && JSON.stringify([...ids].sort()) === JSON.stringify([...selection.retestUnitIds].sort())
    && actual.results.every((record) => record.runId === plan.runId && same(record.candidate, plan.candidate)
      && record.executionEnvironmentSha256 === plan.executionEnvironmentSha256 && SHA.test(record.evidenceSha256)),
    'Missing/extra/duplicate/unbound affected retest results');
  const unresolved = boundary.tickets.filter((ticket) => ticket.outcome?.status !== 'applied');
  const ownFailuresRetested = boundary.tickets.every((ticket) => actual.results.some((record) => record.id === ticket.unitId
    && ['passed', 'conditional-skip'].includes(record.status)));
  const passed = actual.completeCoverageVerified === true && SHA.test(actual.caseLedgerSha256)
    && sourceProof(actual.sourcePreservationProof, plan, snapshot) && actual.lifecycleVerified === true
    && SHA.test(actual.lifecycleEvidenceSha256) && actual.results.every((record) => ['passed', 'conditional-skip'].includes(record.status))
    && unresolved.length === 0 && ownFailuresRetested && boundary.wave.ok === true && boundary.wave.tainted === false;
  return { passed, actual, unresolvedTicketIds: unresolved.map((ticket) => ticket.id),
    actualRetestUnits: ids.length, originalFailureWasNotRewritten: true, writerReplayAllowed: false, releaseGatePassed: false };
}

// No default source, AI provider, edits or test launches. Instantiate only after
// root selects the real source and seals its actual WORKING bytes, not HEAD/index.
export async function createWorkingRepairSession({ plan: input, snapshot, workingRoot,
  immutableRoot, evidenceRoot, authority, providers = [], repairSlots = 4, signal }) {
  const initialPlan = preparePlan(input); let planningPlan = initialPlan;
  check(initialPlan.caseSensitive === (process.platform !== 'win32'), 'Writer runtime filesystem case semantics must match frozen plan');
  check(same(snapshot?.candidate, initialPlan.candidate)
    && snapshot.executionEnvironmentSha256 === initialPlan.executionEnvironmentSha256
    && SHA.test(snapshot.sourceManifestSha256), 'Exact working-byte snapshot/environment required');
  check(authority?.rootReviewed === true && SHA.test(authority.approvalSha256)
    && SHA.test(authority.sourceIdentityReceiptSha256) && authority.exclusiveWriterOwner === true
    && typeof authority.sourceIdentity === 'string', 'Explicit actual-source authority and single writer owner required');
  check(Number.isInteger(repairSlots) && repairSlots >= 1 && repairSlots <= 4, 'Bounded repair provider/writer pool required');
  const root = await realpath(workingRoot); const frozen = await realpath(immutableRoot);
  const journal = await realpath(evidenceRoot);
  check(root === await realpath(resolve(authority.expectedWorkingRoot)) && outside(root, frozen) && outside(frozen, root)
    && outside(root, journal) && outside(journal, root) && outside(frozen, journal) && outside(journal, frozen), 'Distinct non-nested selected working/frozen/private evidence roots required');
  const tickets = new Map(); const registry = new Map(); let busy = false;
  let canonical = null; let oldResults = {}; let oldSourceProven = false; let wave = null; let next = null; let selection = null; let retestConsumed = false;
  const stats = { failuresCaptured: 0, providersStarted: 0, proposalsReturned: 0,
    approvedProposals: 0, actualWorkingReplacements: 0, repairsFailed: 0,
    retestUnitsQueued: 0, retestUnitsExecuted: 0, activeProviders: 0, peakProviders: 0 };
  for (const provider of providers) {
    check(typeof provider.id === 'string' && /^[A-Za-z0-9._-]+$/.test(provider.id)
      && !registry.has(provider.id) && ['codex', 'manual'].includes(provider.kind)
      && provider.rootReviewed === true && SHA.test(provider.approvalSha256)
      && typeof provider.propose === 'function', 'Explicit reviewed Codex/manual proposal provider required');
    registry.set(provider.id, provider);
  }
  const persist = async (ticket) => {
    ticket.version++;
    const record = { schema: 5, ...structuredClone(ticket), proposal: ticket.proposal ? {
      ...ticket.proposal, edits: ticket.proposal.edits.map((edit) => ({ ...edit, bytes: encoded(Buffer.from(edit.bytes)) })) } : null };
    const bytes = Buffer.from(`${JSON.stringify(record, null, 2)}\n`);
    const path = join(journal, `${ticket.id}.v${ticket.version}.json`);
    const handle = await open(path, 'wx', 0o600);
    try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
    ticket.latestJournal = { path, sha256: digestBytes(bytes) }; return ticket;
  };
  const capture = async ({ unitId, ownerId, framework, failedCases, receiptBytes,
    reportBytes = null, intendedWrites = [], confirmedAssertionFailure, sourceLifecycleReady }) => {
    check(tickets.size < 1024 && Buffer.isBuffer(receiptBytes) && receiptBytes.length <= 4 * 1024 ** 2, 'Bounded original receipt bytes required');
    check(!reportBytes || Buffer.isBuffer(reportBytes) && reportBytes.length <= 16 * 1024 ** 2, 'Bounded actual report required');
    const evidence = { receipt: encoded(receiptBytes), report: reportBytes ? encoded(reportBytes) : null };
    const id = `failure-${digestBytes(Buffer.from(JSON.stringify({ unitId, evidence }))).slice(0, 24)}`;
    if (tickets.has(id)) return structuredClone(tickets.get(id));
    const ticket = { id, version: 0, runId: initialPlan.runId, candidate: initialPlan.candidate,
      sourceIdentity: authority.sourceIdentity, sourceIdentityReceiptSha256: authority.sourceIdentityReceiptSha256,
      unitId, ownerId, framework, failedCases, originalRawEvidence: evidence,
      confirmedAssertionFailure, sourceLifecycleReady, intendedWrites: keys(intendedWrites, initialPlan.caseSensitive),
      state: confirmedAssertionFailure ? 'waiting-provider' : 'infrastructure-review-required',
      reason: 'Original failure remains unresolved; no source fix or retest occurred',
      proposal: null, approval: null, outcome: null };
    tickets.set(id, ticket); stats.failuresCaptured++; await persist(ticket); return structuredClone(ticket);
  };
  const requireTicket = (id) => { const ticket = tickets.get(id); check(ticket, 'Unknown failure ticket'); return ticket; };
  const providerWaiters = [];
  const enterProvider = async () => {
    if (stats.activeProviders >= repairSlots) { await new Promise((accept) => providerWaiters.push(accept)); return; }
    stats.activeProviders++; stats.peakProviders = Math.max(stats.peakProviders, stats.activeProviders);
  };
  const leaveProvider = () => { const waiter = providerWaiters.shift(); if (waiter) waiter(); else stats.activeProviders--; };
  const frozenBoundary = () => {
    check(next && selection && wave && !wave.tainted && SHA.test(next.freezeReceiptSha256), 'Actual completed freeze required');
    return structuredClone({ schema: 5, writerReplayAllowed: false, initialRunId: initialPlan.runId,
      initialCandidate: initialPlan.candidate, actualSourceIdentity: authority.sourceIdentity,
      sourceIdentityReceiptSha256: authority.sourceIdentityReceiptSha256, next, selection, wave,
      tickets: [...tickets.values()].map(({ id, unitId, ownerId, state, outcome, latestJournal, originalRawEvidence }) => ({
        id, unitId, ownerId, state, outcome, latestJournal, originalReceiptSha256: originalRawEvidence.receipt.sha256,
        originalReportSha256: originalRawEvidence.report?.sha256 ?? null })) });
  };
  return Object.freeze({
    ingestNative: async (mappingInput, { receiptBytes, intendedWrites = [] } = {}) => {
      check(Buffer.isBuffer(receiptBytes), 'Original native host receipt bytes required');
      const receipt = JSON.parse(receiptBytes);
      check(receipt.status === 'failed', 'Only actual failed native receipt produces a failure ticket');
      const mapped = mapNativeReport({ ...mappingInput, ownerReceipt: receipt, plan: initialPlan, snapshot });
      const file = mapped.files[0];
      return capture({ unitId: file.id, ownerId: file.id, framework: 'native-node', receiptBytes,
        reportBytes: mappingInput.reportBytes, failedCases: file.failedCases, intendedWrites,
        confirmedAssertionFailure: file.assertionFailure && mapped.infrastructureReviewRequired === false,
        sourceLifecycleReady: mapped.lifecycleVerified && mapped.sourcePreservationVerified
          && mapped.infrastructureReviewRequired === false && receipt.exitCode === 1 });
    },
    ingestCanonical: async (mappingInput, { receiptBytes, intendedWritesByFile = {} } = {}) => {
      check(Buffer.isBuffer(receiptBytes), 'Original canonical receipt bytes required');
      const rawReceipt = JSON.parse(receiptBytes);
      check(Buffer.isBuffer(mappingInput.reportBytes) && rawReceipt.reportSha256 === digestBytes(mappingInput.reportBytes)
        && rawReceipt.runId === initialPlan.runId && same(rawReceipt.candidate, initialPlan.candidate), 'Original canonical owner evidence mismatch');
      canonical = mapCanonicalReport({ ...mappingInput, ownerReceipt: rawReceipt, plan: initialPlan, snapshot });
      const expanded = logicalCanonicalPlan(initialPlan, canonical); planningPlan = expanded.plan;
      const captured = [];
      for (const file of canonical.files.filter((entry) => entry.assertionFailure)) captured.push(await capture({
        unitId: file.id, ownerId: 'canonical-units', framework: 'vitest', receiptBytes,
        reportBytes: mappingInput.reportBytes,
        failedCases: file.caseIdentities.filter((item) => item.status === 'failed'),
        intendedWrites: intendedWritesByFile[file.path] ?? [], confirmedAssertionFailure: file.cases.failed > 0,
        sourceLifecycleReady: canonical.lifecycleVerified && canonical.sourcePreservationVerified && !canonical.globalError }));
      if (canonical.infrastructureReviewRequired) captured.push(await capture({ unitId: 'canonical-units', ownerId: 'canonical-units', framework: 'vitest-infrastructure', receiptBytes,
        reportBytes: mappingInput.reportBytes, failedCases: [], intendedWrites: [], confirmedAssertionFailure: false, sourceLifecycleReady: false }));
      return { mapped: canonical, tickets: captured, actualTestsExecuted: 0 };
    },
    bindInitialResults: ({ results, sourcePreservationProof }) => {
      check(Array.isArray(results), 'Actual initial result records required');
      check(new Set(results.map((result) => result.id)).size === results.length && results.every((result) => initialPlan.units.some((unit) => unit.id === result.id)
        && result.runId === initialPlan.runId && same(result.candidate, initialPlan.candidate)
        && result.executionEnvironmentSha256 === initialPlan.executionEnvironmentSha256), 'Unique exact initial owner records required');
      oldSourceProven = sourceProof(sourcePreservationProof, initialPlan, snapshot);
      oldResults = Object.fromEntries(results.map((result) => [result.id, structuredClone(result)]));
      if (canonical) Object.assign(oldResults, logicalCanonicalPlan(initialPlan, canonical).previousFileResults);
      // Source/coverage uncertainty cannot retain green, but does not prevent
      // investigation of a genuine named failure or reviewed actual source fix.
      if (!oldSourceProven) for (const record of Object.values(oldResults)) record.status = 'review-required';
    },
    requestProposal: async (ticketId, providerId) => {
      const ticket = requireTicket(ticketId); check(ticket.proposal === null && ['waiting-provider', 'review-required'].includes(ticket.state)
        && ticket.providerReserved !== true && ticket.confirmedAssertionFailure, 'No silent re-proposal, duplicate provider or infrastructure-as-app-fix');
      const provider = registry.get(providerId);
      if (!provider) { ticket.state = 'review-required'; ticket.reason = 'No explicit repair provider configured'; await persist(ticket); return structuredClone(ticket); }
      ticket.providerReserved = true; await enterProvider(); ticket.state = 'provider-active'; stats.providersStarted++;
      try {
        await persist(ticket);
        const answer = await provider.propose({ ticket: structuredClone(ticket), snapshot: structuredClone(snapshot),
          immutableRoot: frozen, signal, sourceWriteAuthority: false });
        check(answer?.status === 'proposed', answer?.reason ?? 'Provider returned no reviewed replacement proposal');
        const reads = keys(answer.reads ?? [], initialPlan.caseSensitive); const edits = []; const seen = new Set();
        check(Array.isArray(answer.edits) && answer.edits.length > 0 && answer.edits.length <= 64, 'Bounded exact replacement proposal required');
        let bytesTotal = 0;
        for (const edit of answer.edits) {
          check(Buffer.isBuffer(edit.bytes) || edit.bytes instanceof Uint8Array, 'Replacement bytes must be explicit byte data');
          const path = resourceKey(edit.path, initialPlan.caseSensitive); const bytes = Buffer.from(edit.bytes);
          check(ticket.intendedWrites.includes(path) && !seen.has(path), 'Undeclared/duplicate intended working-file output'); seen.add(path);
          bytesTotal += bytes.length;
          check(bytes.length <= 16 * 1024 ** 2 && bytesTotal <= 64 * 1024 ** 2
            && edit.baseSha256 === snapshot.sourceHashes[path] && SHA.test(edit.afterSha256)
            && digestBytes(bytes) === edit.afterSha256 && edit.afterSha256 !== edit.baseSha256, 'Exact base/replacement-byte evidence required');
          edits.push({ path, baseSha256: edit.baseSha256, afterSha256: edit.afterSha256, bytes });
        }
        check([...reads, ...seen].every((path) => SHA.test(snapshot.sourceHashes[path])), 'Every diagnostic input needs a verified snapshot hash');
        const proposalSha256 = digestBytes(Buffer.from(JSON.stringify({ providerId, reads,
          edits: edits.map(({ path, baseSha256, afterSha256 }) => ({ path, baseSha256, afterSha256 })) })));
        ticket.proposal = { providerId, providerApprovalSha256: provider.approvalSha256, reads, edits, proposalSha256 };
        ticket.state = 'waiting-exact-patch-approval'; ticket.reason = 'Proposed bytes are not an applied repair'; stats.proposalsReturned++;
      } catch (error) { ticket.state = 'review-required'; ticket.reason = error.message; }
      finally { ticket.providerReserved = false; leaveProvider(); await persist(ticket); }
      return structuredClone(ticket);
    },
    approveProposal: async (ticketId, approval) => {
      const ticket = requireTicket(ticketId);
      check(ticket.proposal && ticket.state === 'waiting-exact-patch-approval' && ticket.sourceLifecycleReady && ticket.confirmedAssertionFailure,
        'Confirmed source/lifecycle/report-bound assertion failure required for application repair');
      check(approval?.rootReviewed === true && SHA.test(approval.approvalSha256)
        && approval.proposalSha256 === ticket.proposal.proposalSha256 && approval.lane === 'application-source', 'Exact patch-specific application approval required');
      ticket.approval = structuredClone(approval); ticket.state = 'approved-awaiting-working-file-queue';
      stats.approvedProposals++; await persist(ticket); return structuredClone(ticket);
    },
    applyApprovedWave: async (ticketIds, { verifyWorkingAuthority }) => {
      check(!busy && !wave && typeof verifyWorkingAuthority === 'function', 'Single reviewed working-file wave/authority verifier required');
      busy = true;
      try {
        const verified = await verifyWorkingAuthority({ workingRoot: root, authority: structuredClone(authority), snapshot });
        check(verified?.sourceIdentity === authority.sourceIdentity && verified.workingRoot === root
          && verified.exclusiveWriterOwner === true && SHA.test(verified.actualReceiptSha256), 'Fresh actual working-volume ownership verification required');
        const approved = ticketIds.map(requireTicket);
        check(approved.length > 0 && new Set(ticketIds).size === ticketIds.length
          && approved.every((ticket) => ticket.state === 'approved-awaiting-working-file-queue'), 'Only unique approved tickets may write');
        const handlers = approved.map((ticket) => ({ id: ticket.id, rootReviewed: true,
          approvalSha256: ticket.approval.approvalSha256, reads: ticket.proposal.reads,
          writes: ticket.proposal.edits.map((edit) => edit.path),
          propose: async () => ({ edits: ticket.proposal.edits.map((edit) => ({ ...edit, bytes: Buffer.from(edit.bytes) })) }) }));
        const queue = await createRepairQueue({ root, immutableRoot: frozen, snapshot, handlers, concurrency: repairSlots, signal });
        const pending = approved.map((ticket) => queue.enqueue({ failedUnitId: ticket.unitId, handlerId: ticket.id,
          runId: initialPlan.runId, candidate: initialPlan.candidate, failureEvidenceSha256: ticket.originalRawEvidence.receipt.sha256 }));
        await Promise.all(pending); wave = await queue.drain(); wave.actualWorkingAuthorityReceiptSha256 = verified.actualReceiptSha256;
        for (const outcome of wave.results) {
          const ticket = requireTicket(outcome.handler); ticket.outcome = outcome;
          ticket.state = outcome.status === 'applied' ? 'working-files-changed-awaiting-retest' : 'repair-failed';
          ticket.reason = outcome.error ?? 'Real selected working-file replacement read back; not yet a verified fix';
          stats.actualWorkingReplacements += outcome.changedFiles.length;
          if (outcome.status !== 'applied') stats.repairsFailed++;
          await persist(ticket);
        }
        return structuredClone(wave);
      } catch (error) {
        wave = { ok: false, tainted: true, results: [], error: error.message, actualWorkingStateReviewRequired: true };
        for (const id of ticketIds) { const ticket = requireTicket(id); ticket.state = 'repair-wave-review-required'; ticket.reason = error.message; await persist(ticket); }
        throw error;
      } finally { busy = false; }
    },
    freezeAndQueueRetests: async ({ freezeCandidate }) => {
      check(!busy && !next && wave && !wave.tainted && wave.results.some((item) => item.status === 'applied')
        && typeof freezeCandidate === 'function', 'Clean actual working-file changes and explicit fresh freeze required');
      busy = true;
      try {
        next = await freezeCandidate({ workingRoot: root, authority: structuredClone(authority), previousSnapshot: snapshot,
          planningPlan, actualChanges: structuredClone(wave), signal });
        const newPlan = preparePlan(next.plan);
        check(same(next.snapshot?.candidate, newPlan.candidate) && newPlan.runId !== initialPlan.runId
          && (newPlan.candidate.commit !== initialPlan.candidate.commit || newPlan.candidate.tree !== initialPlan.candidate.tree)
          && next.fullWorkingManifestVerified === true && SHA.test(next.freezeReceiptSha256), 'Actual changed working bytes/modes must define a fresh immutable candidate');
        check(await realpath(next.immutableRoot) !== root && await realpath(next.immutableRoot) !== frozen,
          'Retests require a NEW immutable read snapshot, never the mutable working preview');
        check(JSON.stringify(newPlan.units.map((unit) => [unit.id, unit.files])) === JSON.stringify(planningPlan.units.map((unit) => [unit.id, unit.files])), 'No dropped/replaced test inventory during freeze');
        for (const result of wave.results) for (const edit of result.changedFiles)
          check(next.snapshot.sourceHashes[edit.path] === edit.afterSha256, 'Freeze omitted actual working replacement');
        selection = planRetests(newPlan, { runId: initialPlan.runId,
          snapshot: { ...snapshot, impactComplete: oldSourceProven && snapshot.impactComplete === true }, results: oldResults }, next.snapshot);
        stats.retestUnitsQueued = selection.retestUnitIds.length;
        return { selection, freezeReceiptSha256: next.freezeReceiptSha256, actualTestsExecuted: 0 };
      } finally { busy = false; }
    },
    exportFrozenBoundary: frozenBoundary,
    executeQueuedRetests: async ({ rootApprovedExecution, executionApprovalSha256, executeBoundRetests }) => {
      check(!busy && !retestConsumed && next && selection && rootApprovedExecution === true && SHA.test(executionApprovalSha256)
        && typeof executeBoundRetests === 'function', 'Separate explicit actual-retest execution authority required');
      busy = true; retestConsumed = true;
      try {
        // Host uses reviewed exact canonical subset bridge and native unit runner;
        // no one-process-per-Vitest-file expansion or compilers are invented here.
        const actual = await executeBoundRetests({ plan: next.plan, snapshot: next.snapshot, selection,
          immutableRoot: next.immutableRoot, executionApprovalSha256, signal });
        const accepted = acceptFrozenRetest(frozenBoundary(), actual);
        const passed = accepted.passed; stats.retestUnitsExecuted = accepted.actualRetestUnits;
        for (const ticket of tickets.values()) if (ticket.outcome?.status === 'applied') {
          const own = actual.results.find((record) => record.id === ticket.unitId);
          ticket.state = passed && ['passed', 'conditional-skip'].includes(own?.status) ? 'repaired-and-retested' : 'retest-failed-or-incomplete';
          ticket.reason = 'Original failure preserved; result derives only from actual new candidate retests';
          ticket.retestEvidenceSha256 = actual.evidenceSha256; await persist(ticket);
        }
        return accepted;
      } finally { busy = false; }
    },
    state: () => ({ status: [...tickets.values()].some((ticket) => ticket.state !== 'repaired-and-retested') ? 'failed-or-pending' : 'no-unresolved-tickets',
      stats: { ...stats }, tickets: [...tickets.values()].map((ticket) => structuredClone(ticket)),
      providerConfigured: registry.size > 0, actualSourceIdentity: authority.sourceIdentity,
      originalRunFailurePreserved: true, releaseGatePassed: false }),
  });
}
