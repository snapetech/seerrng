import { spawn,execFileSync } from 'node:child_process';
import { readFileSync,writeFileSync,mkdirSync,createWriteStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve,join } from 'node:path';
import { finished } from 'node:stream/promises';
const hash=b=>createHash('sha256').update(b).digest('hex');
const check=(v,m)=>{if(!v)throw Error(m);};
const name=n=>typeof n==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/.test(n);

// Explicit outer host only. No execution on import, tests/builds/deployments
// before root review. It creates ONE new isolated RO consumer, not providers.
export async function runReviewedConsumerHost(c){
 check(c.rootReviewed===true&&c.rootApprovedExecution===true&&name(c.containerName)&&name(c.scratchVolume)&&name(c.sourceVolume)&&name(c.dependenciesVolume)&&name(c.metadataVolume),'Explicit reviewed consumer authority/names required');
 const docker=c.dockerBinary??(process.platform==='win32'?'docker.exe':'docker');
 const call=args=>execFileSync(docker,args,{encoding:'utf8',maxBuffer:32*1024*1024,windowsHide:true});
 check(call(['info','--format','{{.ID}}']).trim()===c.actualEngineId,'Actual engine identity changed');
 const image=JSON.parse(call(['image','inspect',c.imageId]))[0];check(image.Id===c.imageId,'Exact existing pinned runtime image required; no pull');
 const absent=args=>{try{call(args);throw Error('Owned operation already exists; no duplicate start');}catch(e){if(e.status!==1)throw e;}};
 absent(['container','inspect',c.containerName]);absent(['volume','inspect',c.scratchVolume]);
 const recipes=resolve(c.packetRoot,'recipes'),trial=resolve(c.packetRoot,'trial'),optionsBytes=readFileSync(join(trial,'options.json'));
 check(hash(optionsBytes)===c.optionsSha256,'Actual sealed options changed');
 const options=JSON.parse(optionsBytes);check(options.rootApprovedExecution===true&&options.expectedCpu===c.cpu&&options.expectedMemoryBytes===c.memoryBytes,'Root sealed actual resources mismatch');
 const attestation=JSON.parse(readFileSync(join(trial,'attestation.json')));
 for(const r of attestation.recipeInputs)check(/^[A-Za-z0-9._-]+$/.test(r.path)&&hash(readFileSync(join(recipes,r.path)))===r.sha256,'Actual reviewed runtime recipe changed');
 mkdirSync(c.evidenceRoot,{mode:0o700});const save=(n,v)=>{const b=Buffer.isBuffer(v)?v:Buffer.from(JSON.stringify(v,null,2)+'\n');writeFileSync(join(c.evidenceRoot,n),b,{flag:'wx',mode:0o600});return{path:join(c.evidenceRoot,n),sha256:hash(b)};};
 call(['volume','create','--label','purpose=isolated-engine-consumer','--label','run='+c.runId,c.scratchVolume]);
 const mounts=[`type=volume,src=${c.sourceVolume},dst=/app,readonly`,`type=volume,src=${c.dependenciesVolume},dst=/app/node_modules,readonly`,`type=volume,src=${c.metadataVolume},dst=/app/.git,readonly`+(c.metadataSubpath?`,volume-subpath=${c.metadataSubpath}`:''),`type=bind,src=${recipes},dst=/recipes,readonly`,`type=bind,src=${trial},dst=/trial,readonly`,`type=volume,src=${c.scratchVolume},dst=/scratch`];
 if(c.toolingVolume){check(name(c.toolingVolume),'Exact optional read-only tooling volume required');mounts.push(`type=volume,src=${c.toolingVolume},dst=/tooling,readonly`);}
 if(c.metadataSubpath)check(!c.metadataSubpath.startsWith('/')&&!c.metadataSubpath.includes('\\')&&c.metadataSubpath.split('/').every(p=>p&&p!=='.'&&p!=='..'),'Unsafe private frozen metadata subpath');
 const args=['create','--name',c.containerName,'--pull=never','--network=none','--init','--read-only','--workdir=/app','--cpus='+c.cpu,'--memory='+c.memoryBytes,'--label','purpose=isolated-engine-consumer','--label','run='+c.runId];if(c.toolingVolume)args.push('--env','PATH=/tooling/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin');for(const m of mounts)args.push('--mount',m);args.push(c.imageId,'node','/recipes/consumer.mjs','/trial/options.json',c.optionsSha256);
 const id=call(args).trim(),beforeBytes=Buffer.from(call(['inspect',id])),before=JSON.parse(beforeBytes)[0];save('created-inspect.json',beforeBytes);
 check(before.Id===id&&before.Image===c.imageId&&before.HostConfig.NetworkMode==='none'&&before.HostConfig.Init&&before.HostConfig.ReadonlyRootfs&&before.Mounts.length===(c.toolingVolume?7:6)&&before.Mounts.filter(m=>m.RW).length===1&&before.Mounts.some(m=>m.Destination==='/scratch'&&m.Name===c.scratchVolume&&m.RW===true)&&(!c.toolingVolume||before.Mounts.some(m=>m.Destination==='/tooling'&&m.Name===c.toolingVolume&&m.RW===false)),'Actual created immutable mounts/isolation differ');
 save('operation-start.json',{id,runId:c.runId,started:new Date().toISOString(),optionsSha256:c.optionsSha256,sourceVolume:c.sourceVolume,metadataVolume:c.metadataVolume,workingCloneNotMutated:true});
 const out=createWriteStream(join(c.evidenceRoot,'stdout.log'),{flags:'wx'}),err=createWriteStream(join(c.evidenceRoot,'stderr.log'),{flags:'wx'});
 const child=spawn(docker,['start','--attach',id],{stdio:['ignore','pipe','pipe'],windowsHide:true});child.stdout.pipe(out);child.stderr.pipe(err);
 const processResult=await new Promise(accept=>{child.once('error',e=>{out.end();err.end();accept({code:null,signal:null,error:e.message});});child.once('close',(code,signal)=>accept({code,signal}));});await Promise.all([finished(out),finished(err)]);
 let finalBytes=Buffer.from(call(['inspect',id])),final=JSON.parse(finalBytes)[0];
 if(final.State.Running){call(['stop','--time','8',id]);finalBytes=Buffer.from(call(['inspect',id]));final=JSON.parse(finalBytes)[0];}
 save('stopped-inspect.json',finalBytes);check(!final.State.Running,'Actual worker still running; no receipt acceptance');
 // Preserve scratch as raw tar, never Windows symlink extraction or deletion.
 const tar=createWriteStream(join(c.evidenceRoot,'scratch.raw.tar'),{flags:'wx'}),tarErr=createWriteStream(join(c.evidenceRoot,'scratch-copy.stderr'),{flags:'wx'});
 const stream=spawn(docker,['cp',id+':/scratch/.','-'],{stdio:['ignore','pipe','pipe'],windowsHide:true});stream.stdout.pipe(tar);stream.stderr.pipe(tarErr);
 const copy=await new Promise(accept=>{stream.once('error',e=>{tar.end();tarErr.end();accept({code:null,error:e.message});});stream.once('close',(code,signal)=>accept({code,signal}));});await Promise.all([finished(tar),finished(tarErr)]);
 let result=null,collectError=null;try{call(['cp',id+':/scratch/consumer-result.json',join(c.evidenceRoot,'consumer-result.json')]);result=JSON.parse(readFileSync(join(c.evidenceRoot,'consumer-result.json')));}catch(e){collectError=e.message;}
 const proof={purpose:'actual-readonly-engine-consumer-host',runId:c.runId,containerId:id,processResult,copy,finalInspect:final,collectError,result,preservedScratchSha256:copy.code===0?hash(readFileSync(join(c.evidenceRoot,'scratch.raw.tar'))):null,passed:processResult.code===0&&final.State.ExitCode===0&&!final.State.OOMKilled&&final.RestartCount===0&&copy.code===0&&result?.completeCoverageVerified===true&&result.lifecycleVerified===true&&result.results.every(r=>['passed','conditional-skip'].includes(r.status)),actualBuilds:0,releaseGatePassed:false};
 const receipt=save('host-receipt.json',proof);return{...proof,receipt};
}
if(process.argv[1]?.replaceAll('\\','/').endsWith('/host.mjs')){try{check(process.argv.length===4,'Usage: node host.mjs review.json REVIEW_SHA256');const b=readFileSync(process.argv[2]);check(hash(b)===process.argv[3],'Host review changed');const result=await runReviewedConsumerHost(JSON.parse(b));process.stdout.write(JSON.stringify({receipt:result.receipt,passed:result.passed})+'\n');process.exitCode=result.passed?0:1;}catch(e){process.stderr.write(e.stack+'\n');process.exitCode=1;}}
