import { readFileSync,writeFileSync,mkdirSync,symlinkSync,statSync,existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join,dirname } from 'node:path';
import { createExecutor } from './adapter.mjs';
import { coordinate } from './controller.mjs';
import { mapCanonicalReport } from './canonical-host-bridge.mjs';
import { mapNativeReport } from './native-host-bridge.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const check=(v,m)=>{if(!v)throw Error(m);};
const pinned=(path,sha)=>{const b=readFileSync(path);check(hash(b)===sha,'Actual input pin mismatch: '+path);return b;};
const save=(name,value)=>{const b=Buffer.from(JSON.stringify(value,null,2)+'\n');writeFileSync('/scratch/'+name,b,{flag:'wx',mode:0o600});return{path:'/scratch/'+name,sha256:hash(b)};};
const exact=(a,b)=>JSON.stringify([...a].sort())===JSON.stringify([...b].sort());

// Literal isolated full/affected worker. CLI is explicit; no source mutation,
// default background execution, compiler, installs, provider/real DB actions.
export async function runConsumer(options){
 const plan=JSON.parse(pinned(options.planPath,options.planSha256));
 const input=JSON.parse(pinned(options.boundaryPath,options.boundarySha256));
 const snapshot=input.next.snapshot;
 const expectedLedgerBytes=pinned(options.caseLedgerPath,options.caseLedgerSha256);
 const expectedLedger=JSON.parse(expectedLedgerBytes);
 check(options.rootApprovedExecution===true&&input.writerReplayAllowed===false&&snapshot.sourceManifestSha256===JSON.parse(readFileSync(options.attestationPath)).fullSourceManifestSha256,'Exact frozen boundary/actual manifest required');
 check(expectedLedger.complete===true&&expectedLedger.candidate.tree===plan.candidate.tree&&expectedLedger.candidate.commit===plan.candidate.commit&&expectedLedger.executionEnvironmentSha256===plan.executionEnvironmentSha256,'Pinned current source/case ledger required');
 const attestation=JSON.parse(readFileSync(options.attestationPath));
 // Logical writer reservations are exclusively reviewed scratch fixtures.
 // Adapter verifies actual source/dependency/metadata RO mounts before spawn.
 check(options.scratchRoot==='/scratch','Scratch-only reservation root required');
 for(const unit of plan.units){
  const canonical=['canonical-units','canonical-quiet'].includes(unit.id);
  if(canonical){check(unit.writes.length===0,'Canonical source writes forbidden');continue;}
  const readonly=attestation.reviewedReadonlyUnits?.includes(unit.id);
  const fixture=attestation.reviewedFixtureUnits?.includes(unit.id);
  check(readonly!==fixture&&/^(node|tooling)-[a-f0-9]{16}$/.test(unit.id),'Explicit exclusive native effect review required');
  check(unit.writes.length===1&&unit.writes[0]==='scratch/'+unit.id,'Only exact per-unit scratch write reservations allowed');
  if(fixture)check(unit.id==='node-83d16d0282bb150f'&&options.fixtureCopyRoots[unit.id]==='/scratch/docs-vendor-source'&&attestation.fixtureCopies[unit.id]?.root==='/scratch/docs-vendor-source','Only exact private docs fixture admitted');
 }
 const docs=plan.units.find(u=>u.lane==='docs-security');
 if(docs){
  const vendor=attestation.docsSecurityVendorFixture,root=options.fixtureCopyRoots[docs.id];check(!existsSync(root)&&vendor.root===join(root,'gen-docs'),'NEW exclusive docs fixture root required');mkdirSync(root,{recursive:true});
  for(const f of vendor.files){const bytes=readFileSync('/app/'+f.path);check(hash(bytes)===f.sha256&&Boolean(statSync('/app/'+f.path).mode&0o111)===(f.mode==='100755'),'Actual frozen docs fixture bytes/modes');const out=join(root,f.path);mkdirSync(dirname(out),{recursive:true});writeFileSync(out,bytes,{flag:'wx',mode:f.mode==='100755'?0o755:0o644});}
  mkdirSync(join(vendor.root,'node_modules'));symlinkSync('../vendor/image-size',join(vendor.root,'node_modules/image-size'),'dir');
  const receipt=save('docs-vendor-preparation.json',{status:'DOCS_SECURITY_VENDOR_EXACT_FIXTURE_READY',candidateTree:plan.candidate.tree,actualTests:0,files:vendor.files});options.docsVendorReceiptSha256=receipt.sha256;
 }
 let executor,report,finalization,error=null,finalizationError=null;
 const owners=new Map();const started=new Date().toISOString();
 try{
  executor=createExecutor(options);
  report=await coordinate(plan,{execute:true,allowDeclaredWrites:true,executor:async(unit,context,signal)=>{
   const raw=await executor.execute(unit,context,signal);
   const scratch=['canonical-units','canonical-quiet'].includes(unit.id)?'/scratch/'+(unit.id==='canonical-units'?'canonical':'canonical-quiet'):join(options.scratchRoot,unit.id);
   const rawReceiptBytes=readFileSync(join(scratch,'receipt.json'));
   const native=!['canonical-units','canonical-quiet'].includes(unit.id);
   const reportBytes=readFileSync(join(scratch,native?'stdout.log':'results.json'));
   const bound={...raw,executionEnvironmentSha256:plan.executionEnvironmentSha256,reportSha256:hash(reportBytes),originalOwnerReceiptSha256:hash(rawReceiptBytes)};
   const receipt=save('owner-'+unit.id+'.json',bound);owners.set(unit.id,{receipt:bound,reportBytes,receiptSha256:receipt.sha256});
   return{...bound,evidenceSha256:receipt.sha256};
  }});
 }catch(e){error=e.stack??e.message;}
 finally{if(executor)try{finalization=executor.finalize();}catch(e){finalizationError=e.stack??e.message;}}
 const lifecycleVerified=Boolean(executor&&!finalizationError&&owners.size===plan.units.length&&[...owners.values()].every(o=>o.receipt.childrenStopped===true&&o.receipt.leftoverGroup===false&&!o.receipt.timedOut&&!o.receipt.aborted&&o.receipt.signal===null&&o.receipt.childIdentity?.verifiedDetachedGroup));
 let preservation=null,lifecycle=null,results=[],mappingError=null;
 if(finalization){
  const receipt={...finalization,executionEnvironmentSha256:plan.executionEnvironmentSha256,sourceManifestSha256:snapshot.sourceManifestSha256,fileCount:finalization.source.fileCount};
  const saved=save('source-preservation.json',receipt);preservation={receipt,evidenceSha256:saved.sha256};
 }
 lifecycle=save('lifecycle.json',{runId:plan.runId,candidate:plan.candidate,lifecycleVerified,owners:[...owners.entries()].map(([id,o])=>({id,receiptSha256:o.receiptSha256,childrenStopped:o.receipt.childrenStopped,childIdentity:o.receipt.childIdentity})),error,finalizationError});
 if(preservation)try{
  for(const unit of plan.units){
   const actual=owners.get(unit.id);if(!actual)continue;
   const args={plan,ownerId:unit.id,ownerReceipt:actual.receipt,reportBytes:actual.reportBytes,snapshot,sourcePreservationSha256:preservation.evidenceSha256,sourcePreservationProof:preservation,caseLedgerBytes:expectedLedgerBytes,caseLedgerSha256:options.caseLedgerSha256,contracts:{},allowedSkips:attestation.reviewedConditionalSkipIdentities};
   const mapped=['canonical-units','canonical-quiet'].includes(unit.id)?mapCanonicalReport(args):mapNativeReport(args);
   save('mapping-'+unit.id+'.json',mapped);results.push(...mapped.files);
  }
 }catch(e){mappingError=e.stack??e.message;}
 const expectedIds=input.selection.retestUnitIds;
 const completeCoverageVerified=!mappingError&&exact(results.map(r=>r.id),expectedIds)&&new Set(results.map(r=>r.id)).size===results.length&&results.every(r=>r.caseInventoryVerified)&&results.length===expectedIds.length;
 const actual={schema:5,repairBoundarySha256:options.boundarySha256,runId:plan.runId,candidate:plan.candidate,results,completeCoverageVerified,caseLedgerSha256:options.caseLedgerSha256,sourcePreservationProof:preservation,lifecycleVerified,lifecycleEvidenceSha256:lifecycle.sha256,report,error,finalizationError,mappingError,started,finished:new Date().toISOString(),actualBuilds:0,releaseGatePassed:false};
 const proof=save('consumer-result-payload.json',actual);actual.evidenceSha256=proof.sha256;const receipt=save('consumer-result.json',actual);
 return{...actual,receipt,passed:!error&&!finalizationError&&!mappingError&&lifecycleVerified&&completeCoverageVerified&&results.every(r=>['passed','conditional-skip'].includes(r.status))};
}
if(process.argv[1]?.endsWith('/consumer.mjs')){
 try{check(process.argv.length===4,'Usage: node consumer.mjs options.json OPTIONS_SHA256');const options=JSON.parse(pinned(process.argv[2],process.argv[3]));const result=await runConsumer(options);process.stdout.write(JSON.stringify({receipt:result.receipt,passed:result.passed,runId:result.runId})+'\n');process.exitCode=result.passed?0:1;}catch(e){process.stderr.write(e.stack+'\n');process.exitCode=1;}
}
