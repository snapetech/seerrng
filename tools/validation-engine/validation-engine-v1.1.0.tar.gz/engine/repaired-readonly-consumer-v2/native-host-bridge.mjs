import { createHash } from 'node:crypto';
const digestBytes=bytes=>createHash('sha256').update(bytes).digest('hex');
import { preparePlan, resourceKey } from './controller.mjs';
import { readNodeTapHierarchy } from './node-tap-hierarchy.mjs';
export { readNodeTapHierarchy } from './node-tap-hierarchy.mjs';

const SHA=/^[a-f0-9]{64}$/;
const check=(ok,message)=>{if(!ok)throw Error(message)};
const same=(a,b)=>a&&b&&['repository','commit','tree','lockSha256'].every(key=>a[key]===b[key]);

// A deliberately narrow reader, NOT a general TAP/YAML parser. Unsupported
// hierarchy or diagnostics retain raw evidence and require reviewed mapping.
// It never executes tests, patches source or converts ambiguous logs into pass.
export function readFlatNodeTap(reportBytes,file){
 check(Buffer.isBuffer(reportBytes),'Actual native stdout bytes required');
 resourceKey(file,true);
 const text=reportBytes.toString('utf8'),lines=text.split(/\r?\n/);
 const issues=[],cases=[];let expectedName=null;let pending=null;let diagnostic=null;
 const summaries={};const plans=[];
 for(let index=0;index<lines.length;index++){
  const line=lines[index];
  if(/^\s+(?:# Subtest:|(?:not )?ok \d|1\.\.)/.test(line))issues.push('Nested TAP requires a real hierarchical reporter');
  if(line.startsWith('Bail out!'))issues.push('TAP bailout');
  const subtest=/^# Subtest: (.*)$/.exec(line);
  if(subtest){if(expectedName!==null)issues.push('Unfinished top-level subtest');expectedName=subtest[1];}
  const result=/^(ok|not ok) (\d+) - (.*)$/.exec(line);
  if(result){
   if(diagnostic)issues.push('Unterminated diagnostic');
   const directive=/^(.*?) # (SKIP|TODO)(?: (.*))?$/i.exec(result[3]);
   const name=directive?directive[1]:result[3],ordinal=Number(result[2]);
   if(!name||name!==expectedName||ordinal!==cases.length+1)issues.push('Case name/ordinal does not match exact Node subtest');
   if(directive&&result[1]==='not ok')issues.push('Contradictory failure/skip directive');
   pending={file,name,ordinal,status:directive?directive[2].toLowerCase():result[1]==='ok'?'passed':'failed',
    skipReason:directive?.[3]??null,line:index+1,rawCompletion:line,diagnosticLines:[],caseId:JSON.stringify([file,ordinal,name])};
   cases.push(pending);expectedName=null;
  }
  if(line==='  ---'){if(!pending||diagnostic)issues.push('Unexpected diagnostic start');diagnostic=pending;}
  if(diagnostic){diagnostic.diagnosticLines.push(line);if(line==='  ...'){diagnostic.rawDiagnostic=diagnostic.diagnosticLines.join('\n');diagnostic=null;}}
  const summary=/^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$/.exec(line);
  if(summary){if(summary[1] in summaries)issues.push('Duplicate TAP summary');summaries[summary[1]]=Number(summary[2]);}
  const plan=/^1\.\.(\d+)$/.exec(line);if(plan)plans.push(Number(plan[1]));
 }
 if(expectedName!==null||diagnostic)issues.push('Incomplete subtest/diagnostic');
 if(!/^TAP version 13\r?\n/.test(text))issues.push('Missing Node TAP13 header');
 if(Object.keys(summaries).length!==7||plans.length!==1||plans[0]!==cases.length||summaries.tests!==cases.length||!cases.length)issues.push('Incomplete or inconsistent native case discovery');
 if(summaries.suites!==0)issues.push('Suite hierarchy unsupported by flat reader');
 if(summaries.cancelled!==0||summaries.todo!==0)issues.push('Cancelled/TODO cases are not accepted');
 const counts={passed:cases.filter(c=>c.status==='passed').length,failed:cases.filter(c=>c.status==='failed').length,skipped:cases.filter(c=>c.status==='skip').length};
 if(summaries.pass!==counts.passed||summaries.fail!==counts.failed||summaries.skipped!==counts.skipped||Object.values(counts).reduce((a,b)=>a+b,0)!==cases.length)issues.push('Case status/summary mismatch');
 for(const test of cases){
  if(!/^  type: 'test'$/m.test(test.rawDiagnostic??''))issues.push('Actual Node test-type diagnostic missing');
  if(test.status==='failed'&&!/^  (?:error|failureType):/m.test(test.rawDiagnostic??''))issues.push('Failure diagnostic missing');
 }
 return {reportSha256:digestBytes(reportBytes),cases,counts,summaries,issues:[...new Set(issues)],complete:issues.length===0,rawBytes:reportBytes.length};
}

export function mapNativeReport({plan:input,ownerId,ownerReceipt,reportBytes,snapshot,
 sourcePreservationSha256,sourcePreservationProof,caseLedgerBytes=null,caseLedgerSha256=null,contracts={},allowedSkips=[]}){
 const plan=preparePlan(input),owner=plan.units.find(unit=>unit.id===ownerId);
 check(owner&&owner.files.length===1&&Buffer.isBuffer(reportBytes),'Exact one-file native unit and actual TAP bytes required');
 const path=resourceKey(owner.files[0],true);
 check(same(ownerReceipt?.candidate,plan.candidate)&&ownerReceipt.runId===plan.runId&&ownerReceipt.unit===owner.id
  &&same(snapshot?.candidate,plan.candidate)&&SHA.test(plan.executionEnvironmentSha256)
  &&ownerReceipt.executionEnvironmentSha256===plan.executionEnvironmentSha256
  &&snapshot.executionEnvironmentSha256===plan.executionEnvironmentSha256&&SHA.test(snapshot.sourceHashes?.[path]),'Actual candidate/environment/payload binding required');
 const parsed=readNodeTapHierarchy(reportBytes,path);
 check(ownerReceipt.reportSha256===parsed.reportSha256,'Host receipt must bind actual native TAP stdout SHA, not summary only');
 check(Array.isArray(ownerReceipt.inputs)&&ownerReceipt.inputs.some(input=>input.path===path&&input.sha256===snapshot.sourceHashes[path]),'Actual native receipt must bind this exact source test payload');
 const lifecycleVerified=ownerReceipt.childrenStopped===true&&ownerReceipt.leftoverGroup===false
  &&ownerReceipt.timedOut===false&&ownerReceipt.aborted===false&&ownerReceipt.signal===null
  &&ownerReceipt.childIdentity?.verifiedDetachedGroup===true&&[0,1].includes(ownerReceipt.exitCode);
 const preserved=sourcePreservationProof?.receipt;
 const sourcePreservationVerified=Boolean(SHA.test(sourcePreservationSha256)
  &&sourcePreservationProof?.evidenceSha256===sourcePreservationSha256&&same(preserved?.candidate,plan.candidate)
  &&preserved.postInputHashesVerified===true&&preserved.executionEnvironmentSha256===plan.executionEnvironmentSha256
  &&SHA.test(snapshot.sourceManifestSha256)&&preserved.sourceManifestSha256===snapshot.sourceManifestSha256
  &&preserved.fileCount===Object.keys(snapshot.sourceHashes).length);
 let caseInventoryVerified=false;
 if(Buffer.isBuffer(caseLedgerBytes)&&SHA.test(caseLedgerSha256)){
  check(digestBytes(caseLedgerBytes)===caseLedgerSha256,'Actual native case ledger bytes differ');
  const ledger=JSON.parse(caseLedgerBytes),entry=ledger.files?.find(file=>file.path===path);
  caseInventoryVerified=Boolean(ledger.complete===true&&same(ledger.candidate,plan.candidate)
   &&ledger.executionEnvironmentSha256===plan.executionEnvironmentSha256&&entry?.payloadSha256===snapshot.sourceHashes[path]
   &&Array.isArray(entry.names)&&JSON.stringify(entry.names)===JSON.stringify(parsed.cases.map(test=>test.name)));
 }
 const skipsReviewed=parsed.cases.filter(test=>test.status==='skip').every(test=>allowedSkips.some(skip=>skip.file===path&&skip.name===test.name&&skip.ordinal===test.ordinal));
 const processConsistent=parsed.counts.failed>0?ownerReceipt.exitCode===1:ownerReceipt.exitCode===0;
 const infrastructureReviewRequired=!lifecycleVerified||!sourcePreservationVerified||!parsed.complete||!skipsReviewed||!processConsistent;
 const coverageInventoryPending=!caseInventoryVerified;
 const assertionFailure=parsed.counts.failed>0;
 const declared=contracts[path],reached=new Set();let complete=true;
 const visit=key=>{if(reached.has(key))return;reached.add(key);if(!SHA.test(snapshot.sourceHashes[key])||!Array.isArray(snapshot.dependencies?.[key])){complete=false;return;}snapshot.dependencies[key].forEach(visit);};
 (declared?.paths??[path]).forEach(visit);
 const contractComplete=declared?.complete===true&&SHA.test(declared.contractSha256)&&declared.paths.includes(path)&&complete;
 const status=infrastructureReviewRequired?'review-required':assertionFailure?'failed':coverageInventoryPending?'review-required':parsed.counts.passed===0?'conditional-skip':'passed';
 const evidenceSha256=digestBytes(Buffer.from(JSON.stringify({reportSha256:parsed.reportSha256,sourcePreservationSha256,path,caseLedgerSha256,parsed})));
 const file={id:owner.id,path,payloadSha256:snapshot.sourceHashes[path],status,assertionFailure,runId:plan.runId,candidate:plan.candidate,
  executionEnvironmentSha256:plan.executionEnvironmentSha256,evidenceSha256,reportSha256:parsed.reportSha256,sourcePreservationSha256,
  cases:parsed.counts,caseIdentities:parsed.cases,failedCases:parsed.cases.filter(test=>test.status==='failed'),caseInventoryVerified,
  contractSha256:contractComplete?declared.contractSha256:null,inputHashes:contractComplete?Object.fromEntries([...reached].sort().map(key=>[key,snapshot.sourceHashes[key]])):null,
  validationInputs:contractComplete?structuredClone(declared):{complete:false,paths:[path]},
  eligibleForRetention:status==='passed'&&caseInventoryVerified&&contractComplete&&snapshot.impactComplete===true,
  executedByMapping:false,importedActualReport:true};
 return {runId:plan.runId,candidate:plan.candidate,reportSha256:parsed.reportSha256,files:[file],actualReportedFileCount:1,
  actualReportedCases:parsed.cases.length,lifecycleVerified,sourcePreservationVerified,sourcePreservationSha256,
  caseLedgerSha256,caseInventoryVerified,coverageInventoryPending,infrastructureReviewRequired,mappingValid:!infrastructureReviewRequired,mappingIssues:parsed.issues,
  failedFiles:assertionFailure?[path]:[],actualTestsExecutedByMapping:0};
}

export async function queueNativeFailures(queue,mapped,handlerByFile={}){
 check(typeof queue?.enqueue==='function','Existing reviewed repair queue required');
 if(mapped.infrastructureReviewRequired)return {requests:[],pendingFiles:mapped.failedFiles,infrastructureReviewRequired:true,actualTestsExecuted:0};
 const requests=await Promise.all(mapped.files.filter(file=>file.assertionFailure).map(async file=>{
  const request={failedUnitId:file.id,candidate:mapped.candidate,runId:mapped.runId,failureEvidenceSha256:file.evidenceSha256,
   handlerId:handlerByFile[file.path]??null,failedFile:file.path,failure:structuredClone(file)};
  return {request,outcome:await queue.enqueue(request)};
 }));
 return {requests,infrastructureReviewRequired:false,actualTestsExecuted:0};
}
