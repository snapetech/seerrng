import { readFileSync,writeFileSync,mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const hash=b=>createHash('sha256').update(b).digest('hex');
const check=(v,m)=>{if(!v)throw Error(m);};
const pinned=d=>{const b=readFileSync(d.path);check(hash(b)===d.sha256,'Root sealed input changed: '+d.path);return b;};
const identity=(a,b)=>['repository','commit','tree','lockSha256'].every(k=>a[k]===b[k]);
const same=(a,b)=>JSON.stringify([...a].sort())===JSON.stringify([...b].sort());
const CORE=['adapter.mjs','config.mjs','isolate-before.mjs','sequencer.mjs','controller.mjs','priority.mjs','verify-working-tree-metadata.mjs','verify-metadata.mjs','consumer.mjs','canonical-host-bridge.mjs','native-host-bridge.mjs','node-tap-hierarchy.mjs','watchlistPreview.overlay.test.mjs','watchlist-overlay.json','watchlist-command-override.mjs'];

// Explicit local packet generation, not tests/build/Docker. Supports initial
// exact full V2 source and later actual repair-freeze boundary without stubs.
export function prepareConsumer(c){
 check(c.rootReviewed===true&&['initial-full','affected-retest'].includes(c.operation),'Root selected full/affected generation required');
 const sourceBytes=pinned(c.sourceManifest),source=JSON.parse(sourceBytes),metadataBytes=pinned(c.metadataManifest);
 const base=JSON.parse(pinned(c.outerPlan)),attestation=JSON.parse(pinned(c.attestationTemplate));
 const candidate={repository:source.repository,commit:source.commit,tree:source.tree,lockSha256:source.lockSha256};
 check(source.fileCount===source.files.length&&source.fileCount===c.expectedSourceFiles&&base.candidate.repository===candidate.repository&&base.candidate.lockSha256===candidate.lockSha256,'Actual complete source/unchanged dependency lock scope required');
 const oldFiles=base.units.flatMap(u=>u.files),canonical=base.units.find(u=>u.id==='canonical-units');
 check(canonical&&oldFiles.length===c.expectedTestFiles&&new Set(oldFiles).size===oldFiles.length,'Exact original full distinct test inventory required');
 const byPath=new Map(source.files.map(f=>[f.path,f]));check(oldFiles.every(p=>byPath.has(p)),'Original unchanged test payloads must be present');
 let boundary;
 if(c.operation==='affected-retest'){
  boundary=JSON.parse(pinned(c.boundary));check(boundary.schema===5&&boundary.writerReplayAllowed===false&&identity(boundary.next.snapshot.candidate,candidate)&&boundary.next.snapshot.sourceManifestSha256===c.sourceManifest.sha256,'Actual changed-source boundary mismatch');
 }else{
  check(identity(base.candidate,candidate),'Initial full uses EXACT existing source, not edited/fetched files');
  const logical=base.units.flatMap(u=>u.id==='canonical-units'?u.files.map(p=>({id:'vitest-'+hash(Buffer.from(p)).slice(0,24),files:[p],payload:{canonicalFile:p}})):[u]);
  check(/^[a-f0-9]{64}$/.test(c.executionEnvironmentSha256),'New root-bound runtime/dependency/resources/recipe environment identity required; prior missing field cannot be inherited');
  boundary={schema:5,operation:'initial-full',writerReplayAllowed:false,next:{snapshot:{candidate,sourceManifestSha256:c.sourceManifest.sha256,sourceHashes:Object.fromEntries(source.files.map(f=>[f.path,f.sha256])),executionEnvironmentSha256:c.executionEnvironmentSha256}},selection:{retestUnitIds:logical.map(u=>u.id)},initialWorkingCloneReceiptSha256:c.actualWorkingCloneReceiptSha256};
  check(/^[a-f0-9]{64}$/.test(c.actualWorkingCloneReceiptSha256),'Actual writable clone must be ready before initial full engine start');
 }
 const selected=new Set(boundary.selection.retestUnitIds),canonicalSelected=canonical.files.filter(p=>selected.has('vitest-'+hash(Buffer.from(p)).slice(0,24)));
 const native=base.units.filter(u=>u.id!=='canonical-units'&&selected.has(u.id)).map(u=>structuredClone(u));
 const known=[...canonicalSelected.map(p=>'vitest-'+hash(Buffer.from(p)).slice(0,24)),...native.map(u=>u.id)];check(same(known,[...selected]),'Missing/unknown selected logical unit IDs');
 const quietAuthority=JSON.parse(pinned(c.quietPartition));check(quietAuthority.rootReviewed===true&&same(quietAuthority.originalCanonicalFiles,canonical.files),'Actual reviewed original quiet partition required');
 const quietFiles=canonicalSelected.filter(p=>quietAuthority.phases.quiet.files.includes(p)),regularFiles=canonicalSelected.filter(p=>!quietFiles.includes(p));
 const plan=structuredClone(base);plan.runId=boundary.next.plan?.runId??c.runId;plan.candidate=candidate;plan.executionEnvironmentSha256=boundary.next.snapshot.executionEnvironmentSha256;plan.units=[...native];
 check(plan.runId!==base.runId&&typeof plan.runId==='string'&&plan.maxSlots===c.totalSlots&&c.regularWorkers+c.nativeAdmissions===plan.maxSlots,'New immutable run and exact total nested slot budget required');
 const group=(id,files,workers,slots,order)=>({...structuredClone(canonical),id,files,slots,reads:files,writes:[],dependsOn:[],validationInputs:{complete:false,paths:files},payload:{...structuredClone(canonical.payload),workers,fileOrder:order,command:['pnpm','exec','vitest','run','--config','/recipes/config.mjs','--configLoader','runner','--reporter=default','--reporter=json','--outputFile=/scratch/'+(id==='canonical-units'?'canonical':'canonical-quiet')+'/results.json'],fileInputs:files.map(p=>byPath.get(p))}});
 if(regularFiles.length)plan.units.unshift(group('canonical-units',regularFiles,c.regularWorkers,c.regularWorkers,regularFiles));
 if(quietFiles.length){const quiet=group('canonical-quiet',quietFiles,1,plan.maxSlots,quietAuthority.quietOrder.filter(p=>quietFiles.includes(p)));quiet.dependsOn=plan.units.map(u=>u.id);plan.units.push(quiet);}
 for(const u of native){check(u.dependsOn.length===0,'Unexpected native semantic dependency requires explicit grouping review');u.validationInputs={complete:false,paths:u.files};u.payload.fileInputs=u.payload.fileInputs.map(f=>{check(byPath.get(f.path)?.sha256===f.sha256,'Explicit maintenance required if original test payload changed');return f;});}
 // Rebind only explicitly reviewed supplemental maintenance, never source bytes.
 for(const [id,binding] of Object.entries(c.reviewedCustomOverlays??{})){
  const unit=native.find(u=>u.id===id);if(!unit)continue;
  check(id==='node-faa273a96b2f9826','Unknown supplemental overlay owner');
  const descriptorPin=c.recipes.find(r=>r.name==='watchlist-overlay.json');
  const descriptor=JSON.parse(pinned(descriptorPin));
  const overlayPin=c.recipes.find(r=>r.name===descriptor.overlay.recipeFile);
  check(binding.descriptorSha256===descriptorPin.sha256&&binding.overlaySha256===descriptor.overlay.sha256&&binding.approvedMaintenancePatchSha256===descriptor.approvedMaintenancePatchSha256,'Exact reviewed descriptor/overlay/patch binding required');
  check(['repository','commit','tree'].every(k=>candidate[k]===descriptor.candidate[k])&&descriptor.unitId===id&&descriptor.applicationSourceMutation===false&&descriptor.canonicalGitHubTestsChanged===false,'Supplemental unchanged-source candidate identity required');
  check(unit.files.length===1&&unit.files[0]===descriptor.sourceInput.path&&JSON.stringify(unit.payload.command)===JSON.stringify(descriptor.originalCommand),'Exact original supplemental test owner/command required');
  for(const input of [descriptor.sourceInput,descriptor.behaviorInput]){const f=byPath.get(input.path);check(f?.sha256===input.sha256&&f.bytes===input.bytes&&(f.gitBlob??f.blob)===input.gitBlob,'Exact unchanged source/behavior provenance required');}
  const overlayBytes=pinned(overlayPin);check(overlayPin.sha256===binding.overlaySha256&&overlayBytes.length===descriptor.overlay.bytes,'Approved overlay bytes required');
  unit.payload.customOverlay=structuredClone(binding);
 }
 plan.scheduling={...plan.scheduling,canonicalWorkers:c.regularWorkers,initialNativeAdmissions:c.nativeAdmissions};plan.coverage={originalDistinctTestInventory:oldFiles.length,selectedDistinctTestFiles:known.length,canonical:canonicalSelected.length,native:native.length};
 for(const g of plan.guardInputs){check(byPath.has(g.path),'Guard file disappeared');g.sha256=byPath.get(g.path).sha256;}
 const ledger=JSON.parse(pinned(c.caseLedger));check(ledger.complete===true&&ledger.files.every(f=>byPath.get(f.path)?.sha256===f.payloadSha256),'Independent unchanged-payload expected case ledger required');ledger.candidate=candidate;ledger.executionEnvironmentSha256=plan.executionEnvironmentSha256;
 check(oldFiles.every(p=>ledger.files.some(f=>f.path===p)),'Full independent named-case expectation inventory missing');
 mkdirSync(c.outputRoot,{mode:0o700});const recipes=join(c.outputRoot,'recipes'),trial=join(c.outputRoot,'trial');mkdirSync(recipes);mkdirSync(trial);
 const save=(root,name,value)=>{const b=Buffer.isBuffer(value)?value:Buffer.from(JSON.stringify(value,null,2)+'\n');writeFileSync(join(root,name),b,{flag:'wx'});return{path:name,sha256:hash(b)};};
 check(same(c.recipes.map(r=>r.name),CORE),'Exact complete runtime recipe closure required');
 const recipeInputs=c.recipes.map(r=>save(recipes,r.name,pinned(r)));recipeInputs.push(save(recipes,'plan.json',plan));
 const bdesc=save(trial,'boundary.json',boundary),ldesc=save(trial,'case-ledger.json',ledger);save(trial,'full-source-manifest.json',sourceBytes);save(trial,'git-metadata.json',metadataBytes);
 attestation.candidateCommit=candidate.commit;attestation.candidateTree=candidate.tree;attestation.lockSha256=candidate.lockSha256;attestation.fullSourceManifestSha256=c.sourceManifest.sha256;attestation.gitMetadata={manifestSha256:c.metadataManifest.sha256};attestation.recipeInputs=recipeInputs;attestation.bootstrap='original-full-setup';attestation.optionalContractCache=false;
 attestation.reviewedReadonlyUnits=attestation.reviewedReadonlyUnits.filter(id=>native.some(u=>u.id===id));attestation.reviewedFixtureUnits=attestation.reviewedFixtureUnits.filter(id=>native.some(u=>u.id===id));
 for(const fixture of Object.values(attestation.fixtureCopies??{}))fixture.candidateTree=candidate.tree;
 if(attestation.docsSecurityVendorFixture)attestation.docsSecurityVendorFixture.candidateTree=candidate.tree;
 if(c.reviewedCustomOverlays)attestation.reviewedCustomOverlays=c.reviewedCustomOverlays;
 save(trial,'attestation.json',attestation);
 const options={...c.runtimeOptions,rootApprovedExecution:true,sourceRoot:'/app',scratchRoot:'/scratch',planPath:'/recipes/plan.json',planSha256:recipeInputs.find(r=>r.path==='plan.json').sha256,attestationPath:'/trial/attestation.json',fullSourceManifestPath:'/trial/full-source-manifest.json',gitMetadataManifestPath:'/trial/git-metadata.json',boundaryPath:'/trial/boundary.json',boundarySha256:bdesc.sha256,caseLedgerPath:'/trial/case-ledger.json',caseLedgerSha256:ldesc.sha256,expectedCpu:c.cpu,expectedMemoryBytes:c.memoryBytes,fixtureCopyRoots:{'node-83d16d0282bb150f':'/scratch/docs-vendor-source'}};
 const odesc=save(trial,'options.json',options);return{operation:c.operation,outputRoot:c.outputRoot,candidate,runId:plan.runId,selectedLogicalIds:[...selected],plannedDistinctFiles:known.length,sourceManifestSha256:c.sourceManifest.sha256,metadataManifestSha256:c.metadataManifest.sha256,recipeInputs,optionsSha256:odesc.sha256,actualTests:0,actualBuilds:0};
}
if(process.argv[1]?.replaceAll('\\','/').endsWith('/prepare-consumer.mjs')){try{check(process.argv.length===4,'Usage: node prepare-consumer.mjs review.json REVIEW_SHA256');const c=JSON.parse(pinned({path:process.argv[2],sha256:process.argv[3]}));process.stdout.write(JSON.stringify(prepareConsumer(c))+'\n');}catch(e){process.stderr.write(e.stack+'\n');process.exitCode=1;}}
