import { mkdirSync,mkdtempSync } from 'node:fs';
import { join } from 'node:path';
const phase=process.env.ENGINE_CANONICAL_PHASE;
if(!['regular','quiet'].includes(phase))throw Error('Explicit actual canonical phase required');
const root='/scratch/'+(phase==='regular'?'canonical':'canonical-quiet');
mkdirSync(join(root,'configs'),{recursive:true});
process.env.NODE_ENV='test';process.env.CONFIG_DIRECTORY=mkdtempSync(join(root,'configs','file-'));
process.env.ALLOW_NETWORK='false';process.env.SEERR_TEST_FAIL_ON_NETWORK='true';
