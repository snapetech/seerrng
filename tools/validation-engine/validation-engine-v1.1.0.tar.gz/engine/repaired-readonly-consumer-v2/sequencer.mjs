import { BaseSequencer } from '/app/node_modules/vitest/dist/node.js';
import { readFileSync,writeFileSync } from 'node:fs';
export default class BoundPhaseSequencer extends BaseSequencer{
 async sort(files){
  const plan=JSON.parse(readFileSync('/recipes/plan.json')),phase=process.env.ENGINE_CANONICAL_PHASE;
  const unit=plan.units.find(u=>u.id===(phase==='regular'?'canonical-units':'canonical-quiet'));
  const paths=files.map(f=>f.moduleId.replace(/^\/app\//,''));
  if(!unit||paths.length!==unit.files.length||new Set(paths).size!==paths.length||JSON.stringify([...paths].sort())!==JSON.stringify([...unit.files].sort()))throw Error('Exact native phase discovery mismatch');
  const order=unit.payload.fileOrder;
  if(!Array.isArray(order)||new Set(order).size!==unit.files.length||JSON.stringify([...order].sort())!==JSON.stringify([...unit.files].sort()))throw Error('Root reviewed whole-file ordering must preserve all phase files');
  const rank=new Map(order.map((p,i)=>[p,i]));const result=[...files].sort((a,b)=>rank.get(a.moduleId.replace(/^\/app\//,''))-rank.get(b.moduleId.replace(/^\/app\//,'')));
  writeFileSync('/scratch/'+(phase==='regular'?'canonical':'canonical-quiet')+'/returned-file-order.json',JSON.stringify(result.map(f=>f.moduleId.replace(/^\/app\//,'')))+'\n',{flag:'wx'});return result;
 }
}
