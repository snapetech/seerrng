import { readFileSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';

const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const check = (value, message) => { if (!value) throw new Error(message); };
const unitId = 'node-faa273a96b2f9826';
const descriptorSha256 = '52690e1bca0b8e9473d38c2c9b334178fab9dbf6ea142f51ea9a07be1cee67b0';
const regular = (path) => { const stat = lstatSync(path); check(stat.isFile() && !stat.isSymbolicLink(), `Nonregular overlay input: ${path}`); };

// Call ONLY from the frozen preflight-verified adapter. Original source file
// inputs remain unchanged/provenance-bound. This creates no process or writes.
export function commandForReviewedCustomOverlay(unit, proof) {
  if (unit.id !== unitId) {
    check(unit.payload.customOverlay === undefined, 'Unknown custom command overlay');
    return { command: [...unit.payload.command], customTestOverlay: null };
  }
  check(proof.attestation.rootReviewed === true && proof.attestation.reviewedReadonlyUnits?.includes(unitId), 'Reviewed RO custom-test owner required');
  const descriptorPath = '/recipes/watchlist-overlay.json'; regular(descriptorPath);
  const descriptorBytes = readFileSync(descriptorPath);
  check(hash(descriptorBytes) === descriptorSha256, 'Reviewed overlay descriptor drift');
  const descriptor = JSON.parse(descriptorBytes);
  check(['repository', 'commit', 'tree'].every((key) => proof.plan.candidate[key] === descriptor.candidate[key]), 'Overlay candidate mismatch');
  const binding = unit.payload.customOverlay;
  const approval = proof.attestation.reviewedCustomOverlays?.[unitId];
  for (const evidence of [binding, approval]) {
    check(evidence?.descriptorSha256 === descriptorSha256
      && evidence.overlaySha256 === descriptor.overlay.sha256
      && evidence.approvedMaintenancePatchSha256 === descriptor.approvedMaintenancePatchSha256,
    'Plan and reviewed attestation must bind exact custom overlay/maintenance');
  }
  check(unit.files.length === 1 && unit.files[0] === descriptor.sourceInput.path
    && unit.payload.fileInputs.some((input) => input.path === descriptor.sourceInput.path
      && input.sha256 === descriptor.sourceInput.sha256 && input.bytes === descriptor.sourceInput.bytes
      && input.blob === descriptor.sourceInput.gitBlob), 'Original custom-test source provenance lost');
  check(JSON.stringify(unit.payload.command) === JSON.stringify(descriptor.originalCommand), 'Unexpected original native command');
  for (const input of [descriptor.sourceInput, descriptor.behaviorInput]) {
    const path = `/app/${input.path}`; regular(path); const bytes = readFileSync(path);
    check(bytes.length === input.bytes && hash(bytes) === input.sha256, 'Bound unchanged application/custom-source input drift');
  }
  const overlayPath = `/recipes/${descriptor.overlay.recipeFile}`; regular(overlayPath);
  const overlayBytes = readFileSync(overlayPath);
  check(overlayBytes.length === descriptor.overlay.bytes && hash(overlayBytes) === descriptor.overlay.sha256, 'Reviewed supplemental overlay drift');
  const command = [...unit.payload.command]; command[command.length - 1] = overlayPath;
  return { command, customTestOverlay: { descriptorSha256, overlaySha256: descriptor.overlay.sha256,
    sourceInput: descriptor.sourceInput, behaviorInput: descriptor.behaviorInput,
    approvedMaintenancePatchSha256: descriptor.approvedMaintenancePatchSha256,
    expectedTests: descriptor.expectedTests, supplementalMaintenance: true,
    applicationSourceChanged: false, canonicalGitHubTestsChanged: false } };
}
