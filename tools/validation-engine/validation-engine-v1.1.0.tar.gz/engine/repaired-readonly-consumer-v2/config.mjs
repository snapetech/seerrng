import original from '/app/vitest.config.mts';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import sequencer from '/recipes/sequencer.mjs';
const bytes=readFileSync('/recipes/plan.json');
if(createHash('sha256').update(bytes).digest('hex')!==process.env.ENGINE_PLAN_SHA256)throw Error('Actual sealed repaired plan hash required');
const plan=JSON.parse(bytes),phase=process.env.ENGINE_CANONICAL_PHASE;
if(!['regular','quiet'].includes(phase))throw Error('Explicit regular/quiet canonical phase required');
const unit=plan.units.find(u=>u.id===(phase==='regular'?'canonical-units':'canonical-quiet'));
if(!unit||new Set(unit.files).size!==unit.files.length||!unit.files.length||Number(process.env.ENGINE_TEST_WORKERS)!==unit.payload.workers||(phase==='quiet'&&unit.payload.workers!==1))throw Error('Exact actual phase inventory/fork allocation required');
const test={...original.test};delete test.minWorkers;delete test.minThreads;delete test.maxThreads;
const originalSetups=Array.isArray(test.setupFiles)?test.setupFiles:test.setupFiles?[test.setupFiles]:[];
if(!originalSetups.length)throw Error('Original authoritative setup/network/config/memory guards must remain');
export default{...original,root:'/app',cacheDir:'/scratch/'+(phase==='regular'?'canonical':'canonical-quiet')+'/cache',test:{...test,
 include:unit.files,setupFiles:['/recipes/isolate-before.mjs',...originalSetups],pool:'forks',isolate:true,fileParallelism:true,maxWorkers:unit.payload.workers,
 sequence:{...test.sequence,concurrent:false,setupFiles:'list',sequencer},passWithNoTests:false,retry:0,allowOnly:false,
}};
