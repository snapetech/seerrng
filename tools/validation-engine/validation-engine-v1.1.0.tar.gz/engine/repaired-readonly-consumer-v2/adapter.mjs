import { createHash } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, realpathSync, statSync, lstatSync, readdirSync, writeFileSync, createWriteStream } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { performance } from 'node:perf_hooks';
import { finished } from 'node:stream/promises';
import { networkInterfaces } from 'node:os';
import { verifyWorkingTreeMetadata } from './verify-working-tree-metadata.mjs';
import { verifyMetadata } from './verify-metadata.mjs';
import { commandForReviewedCustomOverlay } from './watchlist-command-override.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const readJson = (path) => JSON.parse(readFileSync(path, 'utf8'));
const fail = (condition, message) => { if (!condition) throw new Error(message); };
const safeChild = (root, path) => {
  fail(!path.split('/').some((part) => part === '..' || part === '.' || !part) && !path.startsWith('/') && !path.includes('\\'), 'Unsafe relative input');
  const child = resolve(root, path);
  fail(realpathSync(child).startsWith(`${realpathSync(root)}/`), 'Input escaped verified root');
  return child;
};
const REQUIRED_RECIPES = ['adapter.mjs','config.mjs','isolate-before.mjs','sequencer.mjs','plan.json','controller.mjs','priority.mjs','verify-working-tree-metadata.mjs','verify-metadata.mjs','consumer.mjs','canonical-host-bridge.mjs','native-host-bridge.mjs','node-tap-hierarchy.mjs','watchlistPreview.overlay.test.mjs','watchlist-overlay.json','watchlist-command-override.mjs'];
function verifySourceManifest(path, expectedHash, plan) {
  const bytes = readFileSync(path);
  fail(hash(bytes) === expectedHash, 'Actual full source manifest hash mismatch');
  const manifest = JSON.parse(bytes);
  fail(manifest.repository === plan.candidate.repository && manifest.commit === plan.candidate.commit && manifest.tree === plan.candidate.tree && manifest.lockSha256 === plan.candidate.lockSha256 && manifest.packageSha256 === plan.guardInputs.find((input) => input.path === 'package.json').sha256 && Array.isArray(manifest.files) && Number.isSafeInteger(plan.scope.expectedSourceFileCount) && plan.scope.expectedSourceFileCount > 0 && manifest.files.length === plan.scope.expectedSourceFileCount && manifest.files.length === manifest.fileCount, 'Full source manifest candidate/header/declared count mismatch');
  const expected = new Set();
  for (const entry of manifest.files) {
    fail(typeof entry.path === 'string' && !expected.has(entry.path) && /^[a-f0-9]{64}$/.test(entry.sha256) && ['100644', '100755'].includes(entry.mode), 'Invalid/duplicate full source manifest entry');
    expected.add(entry.path);
    const file = safeChild('/app', entry.path);
    fail(!lstatSync(file).isSymbolicLink() && statSync(file).isFile(), `Nonregular source input: ${entry.path}`);
    fail(hash(readFileSync(file)) === entry.sha256 && Boolean(statSync(file).mode & 0o111) === (entry.mode === '100755'), `Full source input/mode mismatch: ${entry.path}`);
  }
  const actual = [];
  const visit = (directory, prefix = '') => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (path === 'node_modules') continue; // separately attested immutable dependency mount
      if (path === '.git') { fail(entry.isDirectory() && !entry.isSymbolicLink(), 'Root Git metadata must be a real dedicated directory'); continue; } // separately hash/HEAD/tree/tag verified RO mount
      fail(!entry.isSymbolicLink(), `Unexpected source symlink: ${path}`);
      if (entry.isDirectory()) visit(join(directory, entry.name), path);
      else { fail(entry.isFile(), `Unexpected source device: ${path}`); actual.push(path); }
    }
  };
  visit('/app');
  fail(JSON.stringify(actual.sort()) === JSON.stringify([...expected].sort()), 'Actual source file set differs from committed snapshot');
  return { sha256: hash(bytes), fileCount: manifest.files.length };
}
function readonlyMount(path) {
  const mount = readFileSync('/proc/self/mountinfo', 'utf8').split('\n').map((line) => line.split(' ')).filter((parts) => parts[4] && (path === parts[4] || path.startsWith(`${parts[4]}/`))).sort((a, b) => b[4].length - a[4].length)[0];
  return mount?.[5].split(',').includes('ro') === true;
}

export function preflight(options) {
  fail(process.platform === 'linux', 'Execution requires isolated Linux; Windows plan generation is not test execution');
  const planPath = options.planPath ?? join(here, 'plan.json');
  const planBytes = readFileSync(planPath);
  fail(hash(planBytes) === options.planSha256, 'Plan hash does not match root-reviewed frozen plan');
  const plan = JSON.parse(planBytes);
  const attestation = readJson(options.attestationPath);
  fail(attestation.rootReviewed === true && attestation.candidateCommit === plan.candidate.commit && attestation.candidateTree === plan.candidate.tree && attestation.lockSha256 === plan.candidate.lockSha256, 'Current-main source/dependency attestation missing or mismatched');
  fail(attestation.dependenciesInstalledForThisLock === true && attestation.nativeSqliteAbiVerified === true, 'Matching dependency/native ABI preparation not proven');
  fail(typeof attestation.fullSourceManifestSha256 === 'string' && typeof options.fullSourceManifestPath === 'string', 'Actual complete candidate manifest bytes required');
  fail(process.versions.node.split('.')[0] === '24' && Number(process.versions.node.split('.')[1]) >= 15, 'Current package requires Node24.15+');
  fail(execFileSync('pnpm', ['--version'], { encoding: 'utf8' }).trim() === '10.24.0', 'Current packageManager pnpm10.24.0 required');
  fail(options.sourceRoot === '/app' && readonlyMount('/app') && readonlyMount('/app/node_modules') && readonlyMount('/recipes'), 'Source, matching dependencies and frozen recipes must be RO mounts');
  fail(Object.values(networkInterfaces()).flat().every((network) => network.internal), 'Network-none namespace required; no bridged interfaces');
  const [quota, period] = readFileSync('/sys/fs/cgroup/cpu.max', 'utf8').trim().split(' ').map(Number);
  const memory = Number(readFileSync('/sys/fs/cgroup/memory.max', 'utf8').trim());
  fail(Number.isFinite(options.expectedCpu) && options.expectedCpu > 0 && Number.isSafeInteger(options.expectedMemoryBytes) && options.expectedMemoryBytes > 0 && Number.isFinite(quota) && quota / period === options.expectedCpu && memory === options.expectedMemoryBytes, 'Exact root-reviewed CPU/memory cgroup limits required');
  const vitest = readJson('/app/node_modules/vitest/package.json');
  fail(vitest.version === '4.1.11', 'Pinned current-lock Vitest4.1.11 required');
  fail(!process.env.GIT_DIR && !process.env.GIT_WORK_TREE, 'Global Git overrides forbidden');
  const gitMount = readFileSync('/proc/self/mountinfo', 'utf8').split('\n').map(line => line.split(' ')).filter(parts => parts[4] === '/app/.git');
  fail(gitMount.length === 1 && gitMount[0][5].split(',').includes('ro') && lstatSync('/app/.git').isDirectory() && !lstatSync('/app/.git').isSymbolicLink(), 'Exact dedicated RO Git metadata mount required');
  fail(typeof options.gitMetadataManifestPath === 'string' && attestation.gitMetadata?.manifestSha256, 'Actual separately pinned Git metadata manifest required');
  const metadataBytes=readFileSync(options.gitMetadataManifestPath);
  const gitMetadata = JSON.parse(metadataBytes).representation==='base-commit-with-actual-working-index-tree'
    ? verifyWorkingTreeMetadata('/app/.git', metadataBytes, attestation.gitMetadata.manifestSha256, plan.candidate, readFileSync(options.fullSourceManifestPath), attestation.fullSourceManifestSha256)
    : verifyMetadata('/app/.git', metadataBytes, attestation.gitMetadata.manifestSha256, plan.candidate);
  const source = verifySourceManifest(options.fullSourceManifestPath, attestation.fullSourceManifestSha256, plan);
  fail(attestation.bootstrap === 'original-full-setup' && attestation.optionalContractCache === false, 'Changed unknown source inputs require original full bootstrap and no unproven optional cache');
  for (const input of [...plan.guardInputs, ...plan.units.flatMap((unit) => unit.payload.fileInputs)]) {
    const file = safeChild('/app', input.path);
    fail(hash(readFileSync(file)) === input.sha256, `Frozen input mismatch: ${input.path}`);
    if (input.mode) fail(Boolean(statSync(file).mode & 0o111) === (input.mode === '100755'), `Executable mode mismatch: ${input.path}`);
  }
  fail(JSON.stringify((attestation.recipeInputs ?? []).map((entry) => entry.path).sort()) === JSON.stringify([...REQUIRED_RECIPES].sort()), 'Exact repaired-consumer recipes must be root-bound; original setup/guards and explicit supplemental maintenance retained');
  for (const recipe of attestation.recipeInputs) fail(hash(readFileSync(safeChild('/recipes', recipe.path))) === recipe.sha256, `Recipe mismatch: ${recipe.path}`);
  return { plan, attestation, source, gitMetadata, planSha256: hash(planBytes), limits: { cpu: quota / period, memoryBytes: memory }, nodeVersion: process.versions.node, vitestVersion: vitest.version };
}

// One sealed run verifies immutable source/deps/recipes once, not59 times.
// Finalization repeats the complete input hash readback once after all children.
export function createExecutor(options) {
  const proof = preflight(options);
  let finalized = false;
  let uncertainChildren = false;
  const active = new Set();
  return Object.freeze({
    execute: async (unit, context, signal) => {
      fail(!finalized && context.runId === proof.plan.runId && ['repository', 'commit', 'tree', 'lockSha256'].every((key) => context.candidate[key] === proof.plan.candidate[key]), 'Sealed executor context mismatch');
      fail(!active.has(unit.id), 'Duplicate active unit');
      active.add(unit.id);
      let spawnAttempted = false;
      try {
        const receipt = await executeBoundUnit(unit.id, { ...options, signal, onSpawnAttempt: () => { spawnAttempted = true; } }, proof);
        if (receipt.childrenStopped !== true) uncertainChildren = true;
        return receipt;
      }
      catch (error) { if (spawnAttempted) uncertainChildren = true; else error.noChildSpawned = true; throw error; }
      finally { active.delete(unit.id); }
    },
    finalize: () => {
      fail(!finalized && active.size === 0 && !uncertainChildren, 'Finalize only once after all children positively stop; uncertain lifecycle must remain failed');
      finalized = true;
      if (proof.plan.units.some((unit) => unit.lane === 'docs-security')) verifyDocsFixture(options, proof);
      const final = preflight(options);
      return { candidate: proof.plan.candidate, source: final.source, postInputHashesVerified: true, actualExecutedByFinalization: 0 };
    },
  });
}

function verifyDocsFixture(options, proof) {
  const id = 'node-83d16d0282bb150f';
  const unit = proof.plan.units.find((entry) => entry.id === id);
  const vendor = proof.attestation.docsSecurityVendorFixture;
  fail(unit?.lane === 'docs-security' && unit.files.length === 1
    && unit.files[0] === 'gen-docs/scripts/image-size-security.test.mjs'
    && unit.payload.cwd === 'gen-docs' && vendor && /^[a-f0-9]{64}$/.test(options.docsVendorReceiptSha256), 'Exact sole docs vendor scope required');
  const root = realpathSync(options.fixtureCopyRoots[id]);
  fail(root.startsWith('/scratch/') && !readonlyMount(root) && vendor.root === join(root, 'gen-docs')
    && vendor.candidateTree === proof.plan.candidate.tree, 'Exclusive scratch docs fixture identity required');
  const receiptPath = '/scratch/docs-vendor-preparation.json';
  fail(hash(readFileSync(receiptPath)) === options.docsVendorReceiptSha256, 'Actual reviewed fixture-preparer return receipt differs');
  const receipt = readJson(receiptPath);
  fail(receipt.status === 'DOCS_SECURITY_VENDOR_EXACT_FIXTURE_READY'
    && receipt.candidateTree === proof.plan.candidate.tree && receipt.actualTests === 0,
    'Real prerequisite receipt, never invented test acceptance');
  const required = ['gen-docs/package.json', 'gen-docs/scripts/image-size-security.test.mjs',
    'gen-docs/vendor/image-size/package.json', 'gen-docs/vendor/image-size/dist/index.mjs',
    'gen-docs/vendor/image-size/dist/index.cjs', 'gen-docs/vendor/image-size/dist/fromFile.mjs',
    'gen-docs/vendor/image-size/dist/fromFile.cjs'];
  fail(Array.isArray(vendor.files) && vendor.files.length === 7
    && JSON.stringify(vendor.files.map((entry) => entry.path).sort()) === JSON.stringify(required.sort()), 'Exact seven committed docs inputs required');
  const manifest = readJson(options.fullSourceManifestPath);
  for (const entry of vendor.files) {
    fail(manifest.files.some((source) => source.path === entry.path && source.sha256 === entry.sha256 && source.mode === entry.mode), 'Docs fixture hash/mode must match current manifest');
    const file = safeChild(root, entry.path);
    fail(hash(readFileSync(file)) === entry.sha256 && Boolean(statSync(file).mode & 0o111) === (entry.mode === '100755'), 'Docs fixture bytes/mode drift');
  }
  const cwd = vendor.root;
  fail(realpathSync(join(cwd, 'node_modules/image-size')) === join(cwd, 'vendor/image-size'), 'Bare docs package resolves only to committed vendor');
  const pkg = readJson(join(cwd, 'vendor/image-size/package.json'));
  fail(readJson(join(cwd, 'package.json')).dependencies['image-size'] === 'file:./vendor/image-size'
    && pkg.name === 'image-size' && pkg.version === '2.0.3'
    && pkg.exports['.'].import === './dist/index.mjs' && pkg.exports['.'].require === './dist/index.cjs'
    && pkg.exports['./fromFile'].import === './dist/fromFile.mjs' && pkg.exports['./fromFile'].require === './dist/fromFile.cjs', 'Exact committed dependency/export contract');
}

async function executeBoundUnit(unitId, options, proof) {
  const unit = proof.plan.units.find((entry) => entry.id === unitId);
  fail(unit, `Unknown frozen unit ${unitId}`);
  fail(options.rootApprovedExecution === true, 'Explicit root-reviewed execution required');
  fail(!options.signal?.aborted, 'Already-aborted execution refused before spawning');
  const canonical = ['canonical-units','canonical-quiet'].includes(unit.id);
  const scratch = canonical ? '/scratch/'+(unit.id === 'canonical-units'?'canonical':'canonical-quiet') : resolve(options.scratchRoot, unit.id);
  fail(scratch.startsWith('/scratch/'), 'Exclusive scratch subdirectory required');
  fail(!existsSync(scratch), 'Scratch exists: no silent retries or reused mutable state');
  mkdirSync(scratch, { recursive: true });
  let cwd = '/app';
  if (!canonical) {
    if (proof.attestation.reviewedReadonlyUnits?.includes(unit.id)) {
      // A reviewed source-reader shares RO inputs; only CONFIG/temp/reports vary.
      cwd = join('/app', unit.payload.cwd);
    } else {
      const fixtureRoot = options.fixtureCopyRoots?.[unit.id];
      fail(fixtureRoot && proof.attestation.reviewedFixtureUnits?.includes(unit.id), 'Noncanonical fixture effects require explicit unit review; no automatic full copy or write fallback');
      const copy = realpathSync(fixtureRoot);
      fail(copy.startsWith('/scratch/') && !readonlyMount(copy), 'Exclusive disposable candidate copy required');
      fail(proof.attestation.fixtureCopies?.[unit.id]?.root === copy && proof.attestation.fixtureCopies[unit.id].candidateTree === proof.plan.candidate.tree, 'Fixture copy provenance not bound');
      cwd = unit.payload.cwd ? join(copy, unit.payload.cwd) : copy;
    }
    if (unit.lane === 'docs-security') verifyDocsFixture(options, proof);
  }
  if (canonical) {
    fail(Number.isInteger(unit.payload.workers) && unit.payload.workers >= 1 && (unit.id === 'canonical-units' ? unit.payload.workers === unit.slots && unit.slots + proof.plan.scheduling.initialNativeAdmissions === proof.plan.maxSlots : unit.payload.workers === 1 && unit.slots === proof.plan.maxSlots), 'Regular native-fork budget or exclusive one-fork quiet reservation must match sealed plan');
  } else {
    fail(unit.slots === 1 && unit.files.length === 1
      && unit.payload.command[0] === 'node' && unit.payload.command[1] === '--test'
      && unit.payload.command.includes('--test-reporter=tap'),
      'Reviewed native unit is exactly one source payload, one outer slot, TAP');
  }
  const env = { PATH: process.env.PATH, HOME: scratch, TMPDIR: scratch, NODE_ENV: 'test', CONFIG_DIRECTORY: join(scratch, 'config'), ALLOW_NETWORK: 'false', SEERR_TEST_FAIL_ON_NETWORK: 'true', CI: 'true', LANG: 'C.UTF-8', ENGINE_TEST_WORKERS: String(canonical?unit.payload.workers:1), ENGINE_PLAN_SHA256: proof.planSha256, ENGINE_CANONICAL_PHASE: canonical?(unit.id==='canonical-units'?'regular':'quiet'):'native' };
  mkdirSync(env.CONFIG_DIRECTORY);
  const stdout = createWriteStream(join(scratch, 'stdout.log'), { flags: 'wx' });
  const stderr = createWriteStream(join(scratch, 'stderr.log'), { flags: 'wx' });
  const started = new Date().toISOString();
  const start = performance.now();
  const { command: reviewedCommand, customTestOverlay } = commandForReviewedCustomOverlay(unit, proof);
  const childArguments = reviewedCommand.slice(1);
  // Optional parser cache deliberately disabled; original tests execute unchanged.
  // User-selected whole-unit watchdog; application per-case deadlines are unchanged.
  const outerTimeoutMs = options.timeoutMs ?? 3600000;
  fail(Number.isSafeInteger(outerTimeoutMs) && outerTimeoutMs > 0 && outerTimeoutMs <= 3600000, 'Explicit positive outer timeout up to 60 minutes required');
  options.onSpawnAttempt?.(); // Only this boundary can introduce a child process.
  const child = spawn(reviewedCommand[0], childArguments, { cwd, env, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  const childIdentity = { pid: child.pid ?? null, pgid: null, sessionId: null, observedFrom: 'Linux /proc/<pid>/stat immediately after spawn', unavailable: null, verifiedDetachedGroup: false };
  if (child.pid) {
    try {
      const raw = readFileSync(`/proc/${child.pid}/stat`, 'utf8');
      const fields = raw.slice(raw.lastIndexOf(')') + 2).trim().split(/\s+/);
      childIdentity.pgid = Number(fields[2]); childIdentity.sessionId = Number(fields[3]);
      childIdentity.verifiedDetachedGroup = Number.isSafeInteger(childIdentity.pgid) && childIdentity.pgid === child.pid;
      if (!childIdentity.verifiedDetachedGroup) childIdentity.unavailable = 'Actual detached process group mismatch; lifecycle acceptance must fail';
    } catch (error) {
      childIdentity.unavailable = error.code === 'ENOENT' ? 'Child exited before /proc identity read; group lifecycle probes remain mandatory' : `Process identity read failed: ${error.code ?? error.message}`;
    }
  } else childIdentity.unavailable = 'Spawn did not produce a child PID';
  child.stdout.pipe(stdout); child.stderr.pipe(stderr);
  let timedOut = false;
  let killTimeout;
  let stopping = false;
  const groupSignal = (signal) => { try { process.kill(-child.pid, signal); } catch (error) { if (error.code !== 'ESRCH') throw error; } };
  const stop = () => { if (stopping) return; stopping = true; groupSignal('SIGTERM'); killTimeout = setTimeout(() => groupSignal('SIGKILL'), 4000); };
  const abort = () => stop();
  options.signal?.addEventListener('abort', abort, { once: true });
  const timeout = setTimeout(() => { timedOut = true; stop(); }, outerTimeoutMs);
  const result = await new Promise((accept) => {
    child.once('error', (error) => { stdout.end(); stderr.end(); accept({ exitCode: null, signal: null, error: error.message }); });
    child.once('close', (exitCode, signal) => accept({ exitCode, signal }));
  });
  clearTimeout(timeout);
  // A parent may exit before its forks. Clear only after all process-group
  // members have stopped; never leave abandoned test children after timeout.
  if (killTimeout) { await new Promise((accept) => setTimeout(accept, 4100)); clearTimeout(killTimeout); }
  options.signal?.removeEventListener('abort', abort);
  await Promise.all([finished(stdout), finished(stderr)]);
  let leftoverGroup = false;
  try { if (child.pid) { process.kill(-child.pid, 0); leftoverGroup = true; } }
  catch (error) { if (error.code !== 'ESRCH') throw error; }
  if (leftoverGroup) {
    groupSignal('SIGTERM');
    await new Promise((accept) => setTimeout(accept, 4000));
    groupSignal('SIGKILL');
  }
  let childrenStopped = !child.pid;
  const stopDeadline = performance.now() + (leftoverGroup || stopping ? 2000 : 0);
  do {
    try { if (child.pid) process.kill(-child.pid, 0); else childrenStopped = true; }
    catch (error) { if (error.code === 'ESRCH') childrenStopped = true; else throw error; }
    if (!childrenStopped && performance.now() < stopDeadline) await new Promise((accept) => setTimeout(accept, 50));
  } while (!childrenStopped && performance.now() < stopDeadline);
  const receipt = { runId: proof.plan.runId, unit: unit.id, candidate: proof.plan.candidate, planSha256: proof.planSha256, started, finished: new Date().toISOString(), elapsedMs: performance.now() - start, ...result, childIdentity, signalledProcessGroup: child.pid ? -child.pid : null, timedOut, leftoverGroup, childrenStopped, aborted: options.signal?.aborted ?? false, inputs: unit.payload.fileInputs, limits: proof.limits, compileTimeIncluded: false, status: 'failed', cases: { passed: 0, failed: 0, skipped: 0 }, cpuMs: null, caseCount: null, reason: 'Process and case report acceptance pending; no invented coverage' };
  if (canonical && existsSync(join(scratch,'results.json'))) {
    const report = readJson(join(scratch,'results.json'));
    receipt.caseCount = report.numTotalTests;
    receipt.passed = report.numPassedTests;
    receipt.failed = report.numFailedTests;
    receipt.reportSha256 = hash(readFileSync(join(scratch,'results.json')));
    const paths = report.testResults.map((file) => file.name.replace(/^\/app\//, '')).sort();
    const expected = [...unit.files].sort();
    receipt.fileDiscoveryVerified = JSON.stringify(paths) === JSON.stringify(expected);
    receipt.caseIdentities = report.testResults.flatMap((file) => file.assertionResults.map((test) => ({ file: file.name.replace(/^\/app\//, ''), name: test.fullName, status: test.status }))).sort((a,b) => `${a.file}:${a.name}`.localeCompare(`${b.file}:${b.name}`));
    receipt.cases = { passed: report.numPassedTests, failed: report.numFailedTests, skipped: report.numPendingTests + (report.numTodoTests ?? 0) };
    const skips = receipt.caseIdentities.filter((test) => test.status !== 'passed' && test.status !== 'failed');
    const allowed = proof.attestation.reviewedConditionalSkipIdentities?.filter(skip=>unit.files.includes(skip.file));
    const skipParity = Array.isArray(allowed) && JSON.stringify(skips.map(({ file, name }) => ({file, name}))) === JSON.stringify([...allowed].sort((a,b) => `${a.file}:${a.name}`.localeCompare(`${b.file}:${b.name}`)));
    receipt.status = result.exitCode === 0 && childIdentity.verifiedDetachedGroup && childrenStopped && !result.signal && !timedOut && !leftoverGroup && !receipt.aborted && report.success === true && receipt.caseCount > 0 && receipt.failed === 0 && receipt.caseCount === receipt.cases.passed + receipt.cases.failed + receipt.cases.skipped && receipt.fileDiscoveryVerified && skipParity ? 'passed' : 'failed';
    receipt.reason = receipt.status === 'passed' ? null : 'Canonical process/report/file/skip acceptance failed; preserve evidence';
  } else if (!canonical) {
    const output = readFileSync(join(scratch, 'stdout.log'), 'utf8');
    const summary = (name) => [...output.matchAll(new RegExp(`^# ${name} (\\d+)\\r?$`, 'gm'))].map((match) => Number(match[1]));
    const sum = (name) => summary(name).reduce((total, value) => total + value, 0);
    if (summary('tests').length === 1 && ['pass', 'fail', 'skipped', 'todo', 'cancelled'].every((name) => summary(name).length === 1)) {
      receipt.cases = { passed: sum('pass'), failed: sum('fail'), skipped: sum('skipped') + sum('todo') };
      receipt.caseCount = sum('tests');
      receipt.status = result.exitCode === 0 && childIdentity.verifiedDetachedGroup && childrenStopped && !result.signal && !timedOut && !leftoverGroup && !receipt.aborted && sum('cancelled') === 0 && receipt.caseCount > 0 && receipt.caseCount === receipt.cases.passed + receipt.cases.failed + receipt.cases.skipped && receipt.cases.failed === 0 && receipt.cases.skipped === 0 ? 'passed' : 'failed';
      receipt.reason = receipt.status === 'passed' ? null : 'Native process/case report acceptance failed';
    } else receipt.reason = 'Native TAP case summary unavailable or ambiguous; not an assumed pass';
  }
  receipt.customTestOverlay = customTestOverlay;
  if (customTestOverlay && receipt.caseCount !== customTestOverlay.expectedTests) {
    receipt.status = 'failed';
    receipt.reason = 'Reviewed supplemental overlay must execute all four original case owners';
  }
  receipt.postInputHashesVerified = null; // session finalization performs once
  const bytes = `${JSON.stringify(receipt, null, 2)}\n`;
  writeFileSync(join(scratch, 'receipt.json'), bytes, { flag: 'wx' });
  receipt.evidenceSha256 = hash(Buffer.from(bytes));
  return receipt;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const mode = process.argv[2] ?? 'plan';
  if (mode === 'plan') {
    const plan = readJson(join(here, 'plan.json'));
    console.log(JSON.stringify({ candidate: plan.candidate, coverage: plan.coverage, units: plan.units.map(({ id, lane, slots, payload }) => ({ id, lane, slots, prerequisite: payload.prerequisite })), actualExecuted: 0 }, null, 2));
  } else if (mode === 'preflight') {
    const options = readJson(process.argv[3]);
    const proof = preflight(options);
    console.log(JSON.stringify({ candidate: proof.plan.candidate, planSha256: proof.planSha256, limits: proof.limits, nodeVersion: proof.nodeVersion, vitestVersion: proof.vitestVersion, actualExecuted: 0 }));
  } else throw new Error('CLI execution disabled; root-reviewed DAG controller must call executeUnit with frozen options');
}
