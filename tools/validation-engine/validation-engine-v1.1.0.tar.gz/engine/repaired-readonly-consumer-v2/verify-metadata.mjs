import { readFileSync, readdirSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';

export function verifyMetadata(root, manifestBytes, expectedManifestSha256, candidate) {
  const sha=b=>createHash('sha256').update(b).digest('hex');
  if(process.env.GIT_DIR||process.env.GIT_WORK_TREE)throw new Error('Global Git overrides prohibited');
  if(!/^[a-f0-9]{64}$/.test(expectedManifestSha256)||sha(manifestBytes)!==expectedManifestSha256)throw new Error('Actual reviewed metadata-manifest pin required');
  const m=JSON.parse(manifestBytes);
  if(m.commit!==candidate.commit||m.tree!==candidate.tree||m.repository!==candidate.repository||!m.tags.length||!m.files.length)throw new Error('Metadata candidate/tag scope mismatch');
  const paths=[];const visit=(dir,prefix='')=>{for(const e of readdirSync(dir,{withFileTypes:true})){const p=prefix?`${prefix}/${e.name}`:e.name;const s=lstatSync(join(dir,e.name));if(s.isSymbolicLink())throw new Error('Metadata aliases prohibited');if(s.isDirectory())visit(join(dir,e.name),p);else{if(!s.isFile())throw new Error('Metadata device prohibited');paths.push(p);}}};visit(root);
  if(new Set(m.files.map(f=>f.path)).size!==m.files.length||JSON.stringify(paths.sort())!==JSON.stringify(m.files.map(f=>f.path).sort()))throw new Error('Metadata full file-set mismatch');
  for(const f of m.files){if(f.path.startsWith('/')||f.path.includes('\\')||f.path.split('/').some(x=>!x||x==='.'||x==='..')||f.path==='objects/info/alternates')throw new Error('Unsafe metadata manifest path');const p=join(root,f.path),s=lstatSync(p);if(!s.isFile()||s.size!==f.bytes||sha(readFileSync(p))!==f.sha256||s.mode&0o111)throw new Error(`Metadata byte/mode drift:${f.path}`);}
  const git=a=>execFileSync('git',[`--git-dir=${root}`,...a],{encoding:'utf8',maxBuffer:16*1024*1024}).trim();
  if(git(['rev-parse','HEAD'])!==m.commit||git(['rev-parse','HEAD^{tree}'])!==m.tree)throw new Error('Metadata actual Git identity drift');
  const tags=git(['ls-remote','--tags',root]).split(/\r?\n/).filter(Boolean).map(l=>{const [object,ref]=l.split('\t');return{ref,object};}).sort((a,b)=>a.ref.localeCompare(b.ref,'en'));
  if(JSON.stringify(tags)!==JSON.stringify(m.tags))throw new Error('Metadata actual full tag refs drift');
  return {commit:m.commit,tree:m.tree,metadataManifestSha256:sha(manifestBytes),files:m.files.length,tagRefs:tags.length};
}
